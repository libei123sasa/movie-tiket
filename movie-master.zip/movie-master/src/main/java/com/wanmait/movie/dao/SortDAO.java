package com.wanmait.movie.dao;

import com.wanmait.movie.util.JDBCDruidUtils;
import com.wanmait.movie.vo.Movie;
import com.wanmait.movie.vo.Pager;;
import com.wanmait.movie.vo.Sort;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;
import org.springframework.web.bind.annotation.RequestMapping;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SortDAO {

    //查询分类表数据总数
    public Integer findTotal()
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());

        String sql = "select COUNT(*) from sort where status=1";

        //BeanHandler  BeanListHandler  MapListHandler  ScalarHandler
        try {
            Object object = queryRunner.query(sql,new ScalarHandler());

            return Integer.parseInt(object.toString());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return null;
    }

    //删除单个电影分类
    public void omitMovie(Sort sort)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql2 = "update sort set status= ? where id = ?";
        try {

            queryRunner.update(sql2,sort.isStatus(),sort.getId());

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    //查询电影分类数量
    public Integer coimtByMovie(String sorts)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select count(*) from sort where status=1 and sorts=?";
        try {
            Object object = queryRunner.query(sql,new ScalarHandler(),sorts);
            return Integer.parseInt(object.toString());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }

    //根据电影分类名查找电影分类
    public Sort getByMovie(String sorts)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select * from sort where sorts = ? and status=1";
        try {
            Sort sort = queryRunner.query(sql,new BeanHandler<>(Sort.class),sorts);
            return sort;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }

    //根据电分类查询
    public Sort getByMovie2(String sortsname)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "SELECT * FROM sort WHERE sorts = ? and status = 1";
        try {
            Sort sort = queryRunner.query(sql, new BeanHandler<>(Sort.class),sortsname);
            return sort;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    //添加电影分类
    public void findMovie(Sort sort)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "insert into sort(sorts,status) values(?,true)";
        try {
            queryRunner.update(sql,sort.getSorts());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    //查出电影分类和id
    public List<Sort> getAll(Pager pager)
    {
        List<Sort> sortList = new ArrayList<>();
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select * from sort where status = 1 LIMIT ?,?";
        try {
            List<Map<String,Object>> maplist = queryRunner.query(sql,new MapListHandler(),(pager.getPageNum()-1)*pager.getPageSize(),pager.getPageSize());
            for (Map<String,Object> map:maplist)
            {
             Sort sort = new Sort();
             sort.setId((Integer) map.get("id"));
             sort.setSorts((String) map.get("sorts"));
             sortList.add(sort);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return sortList;
    }
}
