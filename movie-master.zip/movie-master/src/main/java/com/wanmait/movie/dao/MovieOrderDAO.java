package com.wanmait.movie.dao;

import com.wanmait.movie.util.JDBCDruidUtils;
import com.wanmait.movie.vo.*;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;
import org.springframework.cglib.transform.impl.AddDelegateTransformer;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MovieOrderDAO {

    public int deleteOrder(int orderId) throws SQLException {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "delete from movieorder where orderId = ?";
        int delete = queryRunner.update(sql, orderId);
        return delete;
    }

    //添加订单
    public int addOrder(MovieOrder movieOrder) {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "insert into movieorder(scheduleId, price, userid, orderNumber, payTime) values(?, ?, ?, ?, ?)";
        int add = 0;
        try {
            add = queryRunner.update(sql, movieOrder.getScheduleId(), movieOrder.getPrice(), movieOrder.getUserid(), movieOrder.getOrderNumber(), movieOrder.getPayTime());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return add;
    }

    //根据订单编号查询订单
    public MovieOrder findOrderByNumber(String orderNumber) throws SQLException {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select * from movieorder where orderNumber = ?";
        return queryRunner.query(sql, new BeanHandler<MovieOrder>(MovieOrder.class), orderNumber);
    }

    //添加订单座位
    public int addOrderSeat(Seat seat) {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "insert into order_seat(movieorderid, scheduleid, userid, `row`, col) values(?, ?, ?, ?, ?)";
        int addseat = 0;
        try {
            addseat = queryRunner.update(sql, seat.getMovieorderid(), seat.getScheduleid(), seat.getUserid(), seat.getRow(), seat.getCol());

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return addseat;
    }
    //查询所有人的订单信息
    public List<MovieOrder> findAllMovieOrder(Pager pager)
    {
        List<MovieOrder> movieOrders=new ArrayList<>();
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="SELECT u.username,m.movieName,h.movieHallName,o.orderId,o.orderNumber,o.price,os.row,os.col,s.scheduleDate,s.scheduleTime FROM userinfo u JOIN movieorder o ON u.userid = o.userid JOIN order_seat os ON o.orderId = os.movieorderid JOIN schedule s ON os.scheduleid = s.scheduleId JOIN movie m ON s.movieId = m.movieId JOIN moviehall h ON s.movieHallId = h.moviehallId AND o.status=1 limit ?,?";
        try {
            List<Map<String,Object>> mapList=queryRunner.query(sql,new MapListHandler(),(pager.getPageNum()-1)* pager.getPageSize(),pager.getPageSize());
            for(Map<String,Object> map:mapList)
            {
                MovieOrder movieOrder=new MovieOrder();
                Movie movie=new Movie();
                Moviehall moviehall=new Moviehall();
                Schedule schedule=new Schedule();
                Seat seat=new Seat();
                Userinfo userinfo=new Userinfo();

                movieOrder.setOrderId((Integer)map.get("orderId"));
                movieOrder.setOrderNumber((String) map.get("orderNumber"));
                movieOrder.setPrice((Float)map.get("price"));
                movie.setMovieName((String) map.get("movieName"));
                moviehall.setMovieHallName((String) map.get("movieHallName"));
                schedule.setScheduleDate((Date) map.get("scheduleDate"));
                schedule.setScheduleTime((Time) map.get("scheduleTime"));
                seat.setRow((Integer) map.get("row"));
                seat.setCol((Integer)map.get("col"));
                userinfo.setUsername((String) map.get("username"));

                movieOrder.setMovie(movie);
                movieOrder.setMoviehall(moviehall);
                movieOrder.setSchedule(schedule);
                movieOrder.setSeat(seat);
                movieOrder.setUserinfo(userinfo);

                movieOrders.add(movieOrder);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return movieOrders;
    }

    //根据用户名查询订单信息
    public List<MovieOrder> findAllMovieOrderByusernme(Pager pager,String username)
    {
        List<MovieOrder> movieOrders=new ArrayList<>();
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="SELECT u.username,m.movieName,h.movieHallName,o.orderId,o.orderNumber,o.price,os.row,os.col,s.scheduleDate,s.scheduleTime FROM userinfo u JOIN movieorder o ON u.userid = o.userid JOIN order_seat os ON o.orderId = os.movieorderid JOIN schedule s ON os.scheduleid = s.scheduleId JOIN movie m ON s.movieId = m.movieId JOIN moviehall h ON s.movieHallId = h.moviehallId AND o.status=1 and u.username=? limit ?,?";
        try {
            List<Map<String,Object>> mapList=queryRunner.query(sql,new MapListHandler(),username,(pager.getPageNum()-1)* pager.getPageSize(),pager.getPageSize());
            for(Map<String,Object> map:mapList)
            {
                MovieOrder movieOrder=new MovieOrder();
                Movie movie=new Movie();
                Moviehall moviehall=new Moviehall();
                Schedule schedule=new Schedule();
                Seat seat=new Seat();
                Userinfo userinfo=new Userinfo();

                movieOrder.setOrderId((Integer)map.get("orderId"));
                movieOrder.setOrderNumber((String) map.get("orderNumber"));
                movieOrder.setPrice((Float)map.get("price"));
                movie.setMovieName((String) map.get("movieName"));
                moviehall.setMovieHallName((String) map.get("movieHallName"));
                schedule.setScheduleDate((Date) map.get("scheduleDate"));
                schedule.setScheduleTime((Time) map.get("scheduleTime"));
                seat.setRow((Integer) map.get("row"));
                seat.setCol((Integer)map.get("col"));
                userinfo.setUsername((String) map.get("username"));

                movieOrder.setMovie(movie);
                movieOrder.setMoviehall(moviehall);
                movieOrder.setSchedule(schedule);
                movieOrder.setSeat(seat);
                movieOrder.setUserinfo(userinfo);

                movieOrders.add(movieOrder);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return movieOrders;
    }


    //查询总数
    public  Integer findTotal()
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select count(*) from movieorder where status=1";
        try {
            Object o=queryRunner.query(sql,new ScalarHandler());
            return Integer.parseInt(o.toString());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }
    //查询符合用户名的总记录数
    public Integer CountByUsername(String username)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select count(*) from userinfo,movieorder where userinfo.userid=movieorder.userid and movieorder.status=1 and userinfo.username=?";
        try {
            Object o=queryRunner.query(sql,new ScalarHandler());
            return Integer.parseInt(o.toString());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }

    // 检查座位是否已经被购买
    public boolean isSeatAvailable(int scheduleId, int row, int col) {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select count(*) from order_seat where scheduleid = ? and `row` = ? and col = ?";
        try {
            Long count = queryRunner.query(sql, new ScalarHandler<Long>(), scheduleId, row, col);
            return count == 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    //判断订单是否存在
    public List<MovieOrder> isOrderHave(Integer movieId,Integer userid)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="SELECT * FROM movieorder,schedule WHERE movieorder.scheduleId = schedule.scheduleId AND userid = ? AND movieid = ? and movieorder.status=1";
        try {
            List<MovieOrder> movieOrders=queryRunner.query(sql,new BeanListHandler<>(MovieOrder.class),userid,movieId);
            if (movieOrders.size() == 0){
                return null;
            }
            return movieOrders;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
            return null;
    }
}
