package com.wanmait.movie.webController;

import com.wanmait.movie.dao.UserinfoDAO;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("web")
public class WebForgetPwd3Controller {
    @RequestMapping("forgetPwd3")
    public String forgetPwd3(String username, String password, HttpServletRequest request)
    {
        request.setAttribute("username",username);
        return "web/forgetPwd3";
    }

    @PostMapping("changePassword")
    public String changPassword(String username,String password)
    {
        System.out.println(username+" "+password);
        UserinfoDAO userinfoDAO = new UserinfoDAO();
        userinfoDAO.changePassword(username,password);
        return "web/forgetPwd4";
    }
}
