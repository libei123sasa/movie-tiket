package com.wanmait.movie.webController;

import com.wanmait.movie.dao.MovieDAO;
import com.wanmait.movie.dao.SortDAO;
import com.wanmait.movie.dao.SortMovieDAO;
import com.wanmait.movie.vo.Movie;
import com.wanmait.movie.vo.Pager;
import com.wanmait.movie.vo.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("web")
public class WebGenreController {
    @RequestMapping("genre")
    public String genre(HttpServletRequest request)
    {
        return "web/genre";
    }

    @GetMapping("findBySortsAndPager")
    public String findBySortsAndPager(String sorts, Model model)
    {
        MovieDAO movieDAO = new MovieDAO();
        Pager pager = new Pager();
        pager.setPageNum(1);
        pager.setPageSize(10);

        Integer total = movieDAO.findTotalBySorts(sorts);
        Integer pageCount = total/pager.getPageSize()+(total % pager.getPageSize()==0?0:1);
        pager.setPageCount(pageCount);
        List<Movie> movieList = movieDAO.findMovieBySortsAndPager(sorts, pager);
        model.addAttribute("movieList",movieList);
        model.addAttribute("sorts",sorts);
        model.addAttribute("pager",pager);
        return "web/genre";
    }

    @RequestMapping("sortsChange")
    public String sortsChange(Integer pageNum, Model model,String sorts)
    {
        Pager pager = new Pager();
        pager.setPageNum(pageNum);
        pager.setPageSize(10);
        MovieDAO movieDAO = new MovieDAO();
        List<Movie> movieList = movieDAO.findMovieBySortsAndPager(sorts, pager);
        model.addAttribute("movieList",movieList);
        return "web/sortsList";
    }
}
