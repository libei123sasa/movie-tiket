package com.wanmait.movie.webController;

import com.wanmait.movie.dao.CommentDAO;
import com.wanmait.movie.dao.MovieDAO;
import com.wanmait.movie.dao.SortDAO;
import com.wanmait.movie.vo.Movie;
import com.wanmait.movie.vo.Sort;
import com.wanmait.movie.vo.Userinfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("web")
public class WebIndexController {
    @RequestMapping("index")
    public String index(Model model)
    {
        MovieDAO movieDAO=new MovieDAO();
        List<Movie> movies=movieDAO.getCurrentMovie();
        model.addAttribute("movies",movies);

        List<Movie> movieList=movieDAO.findyvshoumovie();
        model.addAttribute("movieList",movieList);

        return "web/index";
    }
}
