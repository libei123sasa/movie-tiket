package com.wanmait.movie.webController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wanmait.movie.dao.MoviehallDAO;
import com.wanmait.movie.dao.ScheduleDAO;
import com.wanmait.movie.dao.SeatDAO;
import com.wanmait.movie.vo.Moviehall;
import com.wanmait.movie.vo.Schedule;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import java.sql.Date;
import java.sql.Time;
import java.util.List;


@Controller
@RequestMapping("web")
public class WebChooseseatController {
    @RequestMapping("chooseseat")
    public String chooseseat(Model model)
    {
        MoviehallDAO moviehallDAO = new MoviehallDAO();
        List<Moviehall> moviehallList = moviehallDAO.getAllHall();
        model.addAttribute("moviehallList",moviehallList);
        return "web/chooseseat";
    }
    @RequestMapping("getByMovieHallId")
    public String getByMovieHallId(Integer mid, Model model, float price, String movieName, Date date, Time time, String movieHallName, Integer scheduleId)
    {
        MoviehallDAO moviehallDAO = new MoviehallDAO();
        Moviehall moviehall = moviehallDAO.getBymovieHallId(mid);
        model.addAttribute("moviehall",moviehall);
        model.addAttribute("price",price);
        model.addAttribute("movieHallName",movieHallName);
        model.addAttribute("date",date);
        model.addAttribute("time",time);
        model.addAttribute("movieName",movieName);
        model.addAttribute("scheduleId",scheduleId);
        SeatDAO seatDAO = new SeatDAO();
        int[][] seatsByScheduleid = seatDAO.findSeatsByScheduleid(scheduleId);
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            String seats = objectMapper.writeValueAsString(seatsByScheduleid);
            model.addAttribute("seats",seats);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return "web/chooseseat";
    }

}
