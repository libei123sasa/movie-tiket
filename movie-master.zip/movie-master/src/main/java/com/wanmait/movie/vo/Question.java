package com.wanmait.movie.vo;

import lombok.Data;

@Data
public class Question {
    private int qid;//密保问题id
    private String question;//密保问题
}
