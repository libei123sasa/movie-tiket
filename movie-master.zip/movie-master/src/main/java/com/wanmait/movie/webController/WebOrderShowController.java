package com.wanmait.movie.webController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wanmait.movie.dao.MovieOrderDAO;
import com.wanmait.movie.vo.MovieOrder;
import com.wanmait.movie.vo.Seat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Controller
@RequestMapping("web")
public class WebOrderShowController
{
    @RequestMapping("orderShow")
    public String orderShow()
    {

        return "web/orderShow";
    }
    @RequestMapping ("toOrderShow")
    public String toOrderShow(Model model, String seat, Double prices, Integer scheduleid, Integer userid, String username, String movieHallName, String movieName, String date, String time)
    {
        // 解析 JSON 字符串
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            List<String> selectedSeats = objectMapper.readValue(seat, List.class);
            model.addAttribute("selectedSeats",selectedSeats);
            model.addAttribute("movieName",movieName);
            model.addAttribute("username",username);
            model.addAttribute("movieHallName",movieHallName);
            model.addAttribute("date",date);
            model.addAttribute("time",time);
            model.addAttribute("prices",prices);
            model.addAttribute("scheduleId",scheduleid);
            model.addAttribute("userid",userid);
            // 打印接收到的参数
//            System.out.println("Selected Seats: " + selectedSeats);
//            System.out.println("Prices: " + prices);
//            System.out.println("Schedule ID: " + scheduleid);
//            System.out.println("User ID: " + userid);
//            System.out.println("Username: " + username);
//            System.out.println("Movie Hall Name: " + movieHallName);
//            System.out.println("Movie Name: " + movieName);
//            System.out.println("Date: " + date);
//            System.out.println("Time: " + time);

            // 进行业务逻辑处理
            // ...

            // 返回响应
            return "web/orderShow";
        } catch (Exception e) {
            e.printStackTrace();
            return "Error processing order: " + e.getMessage();
        }
    }

    @RequestMapping("addOrder")
    @ResponseBody
    public String addOrder(int scheduleId,float prices,int userid,String orderNumber,String selectedSeatsStr)
    {

        MovieOrderDAO movieOrderDAO = new MovieOrderDAO();
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            int[][] selectedSeats = objectMapper.readValue(selectedSeatsStr, int[][].class);

            // 检查所有选中的座位是否都可用
            for (int[] seat : selectedSeats) {
                int row = seat[0];
                int col = seat[1];
                if (!movieOrderDAO.isSeatAvailable(scheduleId, row, col)) {
                    return "2";
                }
            }

            // 插入订单
            MovieOrder movieOrder = new MovieOrder();
            movieOrder.setScheduleId(scheduleId);
            movieOrder.setPrice(prices);
            movieOrder.setUserid(userid);
            movieOrder.setOrderNumber(orderNumber);
            LocalDateTime now = LocalDateTime.now();
            Timestamp timestamp = Timestamp.valueOf(now);
            movieOrder.setPayTime(timestamp);

            int add = movieOrderDAO.addOrder(movieOrder);
            System.out.println("Order added: " + add);

            if (add == 1) {
                // 获取刚刚插入的订单ID
                MovieOrder insertedOrder = movieOrderDAO.findOrderByNumber(orderNumber);
                if (insertedOrder != null) {
                    movieOrder.setOrderId(insertedOrder.getOrderId());

                    int sum = 0;
                    for (int[] seat : selectedSeats) {
                        int row = seat[0];
                        int col = seat[1];

                        Seat seatObj = new Seat();
                        seatObj.setMovieorderid(movieOrder.getOrderId());
                        seatObj.setScheduleid(scheduleId);
                        seatObj.setUserid(userid);
                        seatObj.setRow(row);
                        seatObj.setCol(col);
                        int i1 = movieOrderDAO.addOrderSeat(seatObj);
                        sum += i1;
                        System.out.println("Seat added: row=" + row + ", col=" + col + ", result=" + i1);
                    }

                    if (sum == selectedSeats.length) {
                        return "1";
                    } else {
                        System.out.println("Not all seats added successfully");
                        // 如果有座位插入失败，删除订单
                        movieOrderDAO.deleteOrder(movieOrder.getOrderId());
                        return "0";
                    }
                } else {
                    return "0";
                }
            } else {
                return "0";
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "0";
    }
}

