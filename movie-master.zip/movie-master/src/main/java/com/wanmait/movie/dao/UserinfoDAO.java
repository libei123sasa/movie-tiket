package com.wanmait.movie.dao;


import com.wanmait.movie.util.JDBCDruidUtils;
import com.wanmait.movie.vo.Pager;
import com.wanmait.movie.vo.Userinfo;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class UserinfoDAO {

    //根据用户名和密码查找用户
    public Userinfo getByUsernameAndPassword(String username,String password)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select * from userinfo where username = ? and password = ?";
        try {
            Userinfo userinfo = queryRunner.query(sql, new BeanHandler<>(Userinfo.class), username, password);
            return userinfo;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    //根据用户名查找用户
    public Userinfo getByUsername(String username)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select * from userinfo where username = ?";
        try {
            Userinfo userinfo = queryRunner.query(sql, new BeanHandler<>(Userinfo.class), username);
            return userinfo;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    //添加用户
    public void add(Userinfo userinfo)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "insert into userinfo(username,password,userPhoto,usermibao,mbdaan,regTime,updatetime) values(?,?,?,?,?,?,?)";
        try {
            queryRunner.update(sql,userinfo.getUsername(),userinfo.getPassword(),userinfo.getUserPhoto(),userinfo.getUsermibao(),userinfo.getMbdaan(),userinfo.getRegTime(),userinfo.getUpdateTime());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //根据用户名查询密保和答案
    public Userinfo getQAbyUsername(String username,String usermibao,String mbdaan){
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select * from userinfo where username=? and usermibao = ? and mbdaan = ?";
        try {
            Userinfo userinfo = queryRunner.query(sql, new BeanHandler<>(Userinfo.class), username, usermibao, mbdaan);
            return userinfo;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    //修改密码
    public void changePassword(String username,String password){

        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "update userinfo set password = ? where username = ?";
        try {
            queryRunner.update(sql,password,username);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    //查找所有用户
    public List<Userinfo> getAllUser()
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select * from userinfo";
        try {
            List<Userinfo> userinfos=queryRunner.query(sql,new BeanListHandler<>(Userinfo.class));
            return userinfos;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
            return null;
    }
    //根据用户id修改用户信息
    public void updateByUserId(Userinfo userinfo)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="update userinfo set username=?,password=?,userPhoto=?,usermibao=?,mbdaan=?,updatetime=? where userid=?";
        try {
            queryRunner.update(sql,userinfo.getUsername(),userinfo.getPassword(),userinfo.getUserPhoto(),userinfo.getUsermibao(),userinfo.getMbdaan(),userinfo.getUpdateTime(),userinfo.getUserid());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    //查询用户表数据总数
    public Integer findTotal()
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select count(*) from userinfo where status=1";
        try {
            Object object=queryRunner.query(sql, new ScalarHandler());
            return Integer.parseInt(object.toString());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }
    //查询某页数据
    public List<Userinfo> findByPager(Pager pager)
    {
        List<Userinfo> userinfos=new ArrayList<>();
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select * from userinfo  limit ?,? ";
        try {
            List<Map<String,Object>> mapList=queryRunner.query(sql,new MapListHandler(),(pager.getPageNum()-1)* pager.getPageSize(),pager.getPageSize());
            for(Map<String,Object> map:mapList)
            {
                Userinfo userinfo=new Userinfo();
                userinfo.setUserid((Integer)map.get("userid"));
                userinfo.setUsername((String) map.get("username"));
                userinfo.setPassword((String) map.get("password"));
                userinfo.setUserPhoto((String) map.get("userPhoto"));
                userinfo.setUsermibao((String) map.get("usermibao"));
                userinfo.setMbdaan((String) map.get("mbdaan"));
                userinfo.setStatus((boolean) map.get("status"));

                userinfos.add(userinfo);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return userinfos;
    }
    //删除单个用户
    public int deleteByUserNaame(String username)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="update userinfo set status=0 where username=?";
        try {
            int update = queryRunner.update(sql, username);
            return update;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return 0;
    }
    //统计查询的用户名数量
    public Integer countByUsername(String username)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select count(*) from userinfo where status=1 and username=?";
        try {
            Object object = queryRunner.query(sql, new ScalarHandler(),username);
            return Integer.parseInt(object.toString());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }
}
