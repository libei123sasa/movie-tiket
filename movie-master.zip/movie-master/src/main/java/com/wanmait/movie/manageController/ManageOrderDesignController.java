package com.wanmait.movie.manageController;

import com.wanmait.movie.dao.MovieOrderDAO;
import com.wanmait.movie.vo.MovieOrder;
import com.wanmait.movie.vo.Pager;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

@ControllerAdvice
@RequestMapping("manage")
public class ManageOrderDesignController
{
    @RequestMapping("orderDesign")
    public String orderDesign(Model model)
    {
        Pager pager=new Pager();
        pager.setPageNum(1);
        pager.setPageSize(6);

        MovieOrderDAO movieOrderDAO=new MovieOrderDAO();
        List<MovieOrder> movieOrders=movieOrderDAO.findAllMovieOrder(pager);
        model.addAttribute("movieOrders",movieOrders);

        //总页数
        Integer total=movieOrderDAO.findTotal();
        Integer pageCount=total/pager.getPageSize()+(total%pager.getPageSize()==0?0:1);
        pager.setPageCount(pageCount);
        model.addAttribute("pager",pager);

        return "manage/orderDesign";
    }
    //根据用户名查询
    @RequestMapping("FindByUsername")
    public String FindByUsername(String username,Model model)
    {
        Pager pager=new Pager();
        pager.setPageNum(1);
        pager.setPageSize(6);

        MovieOrderDAO movieOrderDAO=new MovieOrderDAO();
        Integer pageCount=movieOrderDAO.CountByUsername(username);
        pager.setPageCount(pageCount);
        model.addAttribute("pager",pager);

        List<MovieOrder> movieOrders=movieOrderDAO.findAllMovieOrderByusernme(pager,username);
        if(movieOrders!=null)
        {
            model.addAttribute("movieOrders",movieOrders);
        }
        else
        {
            model.addAttribute("movieOrders",new ArrayList<>());
        }
        model.addAttribute("username",username);
        return "manage/orderDesign";
    }
    //ajax
    @RequestMapping("orderChange")
    public String orderChange(Integer pageNum,Model model,String username)
    {
        System.out.println(pageNum);
        Pager pager=new Pager();
        pager.setPageNum(pageNum);
        pager.setPageSize(6);

        MovieOrderDAO movieOrderDAO=new MovieOrderDAO();
        List<MovieOrder> movieOrders;

        if(username!=null&&!username.isEmpty())
        {
            movieOrders=movieOrderDAO.findAllMovieOrderByusernme(pager,username);

        }
        else
        {
            movieOrders=movieOrderDAO.findAllMovieOrder(pager);
            System.out.println(movieOrders);
        }

        model.addAttribute("movieOrders",movieOrders);

        return "manage/orderList";
    }
}

