package com.wanmait.movie.webController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Random;

@Controller
@RequestMapping("web")
public class WebCheckCodeController {
    //生成验证码
    @RequestMapping("create")
    @ResponseBody//不转发
    public void createCheckCode(HttpServletResponse response, HttpServletRequest request)
    {
        //生成验证码字符串
        String code = "";
        Random random = new Random();
        for (int i = 0; i < 4; i++)
        {
            int c = random.nextInt(123);
            if((c>=48&&c<=57)||(c>=65&&c<=90)||(c>=97&&c<=122))
            {
                code += (char)c;
            }
            else
            {
                i--;
            }
        }
        //生成的验证码保存到session
        HttpSession session = request.getSession();
        session.setAttribute("code",code);

        //图片
        BufferedImage image = new BufferedImage(100,50,BufferedImage.TYPE_INT_RGB);
        //image是黑色
        Graphics graphics = image.getGraphics();
        //graphis是白色
        graphics.fillRect(0,0,100,50);
        //画白色 矩形
        graphics.setColor(Color.BLACK);
        //graphics变成黑色
        graphics.setFont(new Font("",Font.BOLD,25));
        //设置文本大小

        graphics.drawString(code,10,35);

        //图片-->jsp
        try {
            OutputStream outputStream = response.getOutputStream();
            ImageIO.write(image,"jpg",outputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @RequestMapping("check")
    @ResponseBody
    public String check(String inputCode, HttpSession session)
    {
        Object o = session.getAttribute("code");
        String code = (String) o;
        if(code.equalsIgnoreCase(inputCode))
        {
            return"1";
        }
        else
        {
            return "0";
        }
    }
}
