package com.wanmait.movie.manageController;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RequestMapping;

@ControllerAdvice
@RequestMapping("manage")
public class ManageCommonController
{
    @RequestMapping("inc/header")
    public String header()
    {
        return "manage/inc/header";
    }
    @RequestMapping("inc/menu")
    public String menu()
    {
        return "manage/inc/menu";
    }
}
