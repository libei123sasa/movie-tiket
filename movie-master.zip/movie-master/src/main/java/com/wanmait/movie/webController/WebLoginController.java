package com.wanmait.movie.webController;

import com.wanmait.movie.dao.UserinfoDAO;
import com.wanmait.movie.util.CookieUtils;
import com.wanmait.movie.vo.Userinfo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("web")
public class WebLoginController {
    @GetMapping("login")
    public String login(){
        return "web/login";
    }

    @PostMapping("login")
    public String login(String username, String password, HttpServletResponse response, HttpSession session, HttpServletRequest request, String autoLogin)
    {
        UserinfoDAO userinfoDAO = new UserinfoDAO();
        Userinfo userinfo = userinfoDAO.getByUsernameAndPassword(username,password);
        if(userinfo!=null)//有数据
        {
            if(userinfo.isStatus()==false)
            {
                request.setAttribute("err","2");
                return "web/login";
            }
            session.setAttribute("userinfo",userinfo);
            if("1".equals(autoLogin))
            {
                //保存到cookie
                Cookie cookie = new Cookie("username",userinfo.getUsername());
                //创建cookie对象
                cookie.setMaxAge(30*24*60*60);
                //设置cookie的有效时间
                cookie.setPath("/");
                //设置cookie的访问路
                response.addCookie(cookie);
                //cookie发送到客户端
                CookieUtils.createCookie("password",userinfo.getPassword(),30*24*60*60,"/",response);

            }
            return "redirect:/web/index";
        }
        else//没数据
        {
            request.setAttribute("err","1");
            return "web/login";
        }

    }

    @RequestMapping("exit")
    public String exit(HttpSession session,HttpServletResponse response)
    {
        session.invalidate();
        CookieUtils.createCookie("username",null,0,"/",response);
        CookieUtils.createCookie("password",null,0,"/",response);
        return "redirect:/web/login";
    }

}
