package com.wanmait.movie.webController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("web")
public class WebForgetIndexController {
    @RequestMapping("forgetIndex")
    public String forget()
    {
        return "web/forgetIndex";
    }
}
