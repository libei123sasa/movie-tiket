package com.wanmait.movie.dao;

import com.wanmait.movie.util.JDBCDruidUtils;
import com.wanmait.movie.vo.Movie;
import com.wanmait.movie.vo.Pager;
import com.wanmait.movie.vo.Sort;
import com.wanmait.movie.vo.SortMovie;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SortMovieDAO {

    //查询所有电影
    public List<Movie> getAllMovie()
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select * from movie where status = 1";
        try {
            List<Movie> movieList = queryRunner.query(sql, new BeanListHandler<>(Movie.class));
            return movieList;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    //查询所有分类
    public List<Sort> getAllSort()
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select * from sort where status = 1";
        try {
            List<Sort> sortList = queryRunner.query(sql, new BeanListHandler<>(Sort.class));
            return sortList;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    //添加电影所属分类
    public void addSortMovie(SortMovie sortMovie)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "insert into sort_movie(movieid,sortsid,updateTime) values(?,?,?)";
        try {
            queryRunner.update(sql,sortMovie.getMovieid(),sortMovie.getSortsid(),sortMovie.getUpdateTime());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //查询电影所属分类是否存在
    public SortMovie ifSortMovieExist(SortMovie sortMovie)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select * from sort_movie where sortsid = ? and movieid = ? and status = 1";
        try {
            SortMovie query = queryRunner.query(sql, new BeanHandler<>(SortMovie.class),sortMovie.getSortsid(),sortMovie.getMovieid());
            return query;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    //查询所有电影所属分类（三表）
    public List<SortMovie> findByPager(Pager pager)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "SELECT m.movieid,sm.id,m.movieName, GROUP_CONCAT(s.sorts SEPARATOR ', ') AS sorts " +
                "FROM movie m, sort_movie sm, sort s " +
                "WHERE  m.movieId = sm.movieid AND sm.sortsid = s.id AND sm.`status` = 1 and m.status = 1 GROUP BY moviename limit ?,?;";
        try {
            List<Map<String, Object>> mapList = queryRunner.query(sql, new MapListHandler(),(pager.getPageNum()-1)* pager.getPageSize(),pager.getPageSize());
            List<SortMovie> sortMovieList = new ArrayList<>();
            for(Map<String,Object> map:mapList)
            {
                SortMovie sortMovie = new SortMovie();
                sortMovie.setId((int) map.get("id"));

                Movie movie  = new Movie();
                movie.setMovieName((String) map.get("moviename"));
                movie.setMovieId((int) map.get("movieid"));
                sortMovie.setMovie(movie);

                Sort sort = new Sort();
                sort.setSorts((String) map.get("sorts"));
                sortMovie.setSort(sort);

                sortMovieList.add(sortMovie);
            }
            return sortMovieList;
        }catch (SQLException throwables) {
            throwables.printStackTrace();
        }
            return null;
    }

    //查询所有条数
    public Integer findTotal()
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select COUNT(*) from(SELECT  sm.id,m.movieName, GROUP_CONCAT(s.sorts SEPARATOR ', ') AS sorts " +
                "FROM movie m, sort_movie sm, sort s " +
                "WHERE  m.movieId = sm.movieid AND sm.sortsid = s.id AND sm.`status` = 1 GROUP BY moviename ) AS temp";
        try {
            Object o = queryRunner.query(sql, new ScalarHandler<>());
            return Integer.parseInt(o.toString());
        } catch (SQLException e) {
            e.printStackTrace();
        }
            return null;
    }

    //删除单个电影所属分类
    public void deleteByMovieId(SortMovie sortMovie)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "update sort_movie set status = ?,updatetime = ? where movieid = ?";
        try {
            queryRunner.update(sql,sortMovie.isStatus(),sortMovie.getUpdateTime(),sortMovie.getMovieid());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    //根据电影名称查询
    public List<SortMovie> findSortMovieByMovieName(String movieName)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "SELECT m.movieId,sm.id,m.movieName, GROUP_CONCAT(sorts SEPARATOR ', ') AS sorts " +
                "FROM movie m, sort_movie sm, sort s " +
                "WHERE  m.movieId = sm.movieid AND sm.sortsid = s.id and sm.`status` = 1 AND m.moviename = ? GROUP BY moviename ;";
        try {
            List<Map<String, Object>> mapList = queryRunner.query(sql, new MapListHandler(), movieName);
            List<SortMovie> sortMovieList = new ArrayList<>();
            for(Map<String,Object> map:mapList)
            {
                SortMovie sortMovie = new SortMovie();
                sortMovie.setId((int) map.get("id"));

                Movie movie  = new Movie();
                movie.setMovieName((String) map.get("moviename"));
                movie.setMovieId((int) map.get("movieid"));
                sortMovie.setMovie(movie);

                Sort sort = new Sort();
                sort.setSorts((String) map.get("sorts"));
                sortMovie.setSort(sort);

                sortMovieList.add(sortMovie);
            }
            return sortMovieList;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

}
