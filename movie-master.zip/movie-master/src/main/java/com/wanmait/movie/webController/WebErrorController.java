package com.wanmait.movie.webController;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("web")
public class WebErrorController {
    @RequestMapping("error")
    public String error(Model model,String movieName)
    {
        model.addAttribute("movieName",movieName);
        return "web/error";
    }
}
