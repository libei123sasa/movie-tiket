package com.wanmait.movie.webController;

import com.wanmait.movie.dao.SortMovieDAO;
import com.wanmait.movie.vo.Sort;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@ControllerAdvice
@RequestMapping("web")
public class WebCommonController {

    @RequestMapping("inc/header")
    public String header(HttpServletRequest request)
    {
        SortMovieDAO sortMovieDAO = new SortMovieDAO();
        List<Sort> allSort = sortMovieDAO.getAllSort();
        request.setAttribute("allSort",allSort);
        return "web/inc/header";
    }
    @RequestMapping("inc/bottom")
    public String bottom(HttpServletRequest request)
    {
        return "web/inc/bottom";
    }

}

