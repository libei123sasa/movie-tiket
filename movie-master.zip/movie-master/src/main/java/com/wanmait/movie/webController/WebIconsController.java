package com.wanmait.movie.webController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("web")
public class WebIconsController {
    @RequestMapping("icons")
    public String icons()
    {
        return "web/icons";
    }
}
