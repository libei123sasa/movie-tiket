package com.wanmait.movie.vo;

import lombok.Data;

@Data
public class Seat {
    private Integer Id;//座位表id
    private Integer movieorderid;//订单表id
    private Integer scheduleid;//场次id
    private Integer userid;//用户id
    private Integer row;//行
    private Integer col;//列
    private boolean status;//状态
}
