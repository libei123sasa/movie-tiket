package com.wanmait.movie.manageController;

import com.wanmait.movie.dao.ScheduleDAO;
import com.wanmait.movie.vo.Movie;
import com.wanmait.movie.vo.Moviehall;
import com.wanmait.movie.vo.Pager;
import com.wanmait.movie.vo.Schedule;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.lang.model.element.NestingKind;
import javax.servlet.http.HttpServletRequest;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

@ControllerAdvice
@RequestMapping("manage")
public class ManageScheduleDesignController
{
    //跳转到scheduleDesign页面，显示第一页数据
    //设置页码
    @RequestMapping("scheduleDesign")
    public String scheduleDesign(Model model)
    {
        Pager pager=new Pager();
        pager.setPageNum(1);
        pager.setPageSize(6);

        ScheduleDAO scheduleDAO=new ScheduleDAO();
        List<Schedule> schedules=scheduleDAO.findByPager(pager);
        model.addAttribute("schedules",schedules);

        //总页数
        Integer total=scheduleDAO.findTotal();
        Integer pageCount=total/pager.getPageSize()+(total%pager.getPageSize()==0?0:1);
        pager.setPageCount(pageCount);
        model.addAttribute("pager",pager);

        //查询所有电影
        List<Movie> movies=scheduleDAO.findMovies();
        model.addAttribute("movies",movies);
        //查询所有放映厅
        List<Moviehall> moviehalls=scheduleDAO.findMoviehalls();
        model.addAttribute("moviehalls",moviehalls);

        return "manage/scheduleDesign";
    }
    //根据电影名查询
    @RequestMapping("findBymovieName")
    public String findBymovieName(String movieName,Model model)
    {
        Pager pager=new Pager();
        pager.setPageNum(1);
        pager.setPageSize(6);

        ScheduleDAO scheduleDAO=new ScheduleDAO();

        //总页数
        Integer total=scheduleDAO.CountBymovieName(movieName);
        Integer pageCount=total/pager.getPageSize()+(total%pager.getPageSize()==0?0:1);
        pager.setPageCount(pageCount);
        model.addAttribute("pager",pager);

        //查询所有电影
        List<Movie> movies=scheduleDAO.findMovies();
        model.addAttribute("movies",movies);
        //查询所有放映厅
        List<Moviehall> moviehalls=scheduleDAO.findMoviehalls();
        model.addAttribute("moviehalls",moviehalls);

        List<Schedule> schedules=scheduleDAO.findBymovieName(movieName,pager);
        if(schedules!=null)
        {
            model.addAttribute("schedules",schedules);
        }
        else
        {
            model.addAttribute("schedules",new ArrayList<>());
        }
        // 将 movieName 添加到模型中
        model.addAttribute("movieName", movieName);

        return "manage/scheduleDesign";
    }
    //Ajax
    @RequestMapping("SmovieChange")
    public String movieChange(Integer pageNum,Model model,String movieName)
    {
        Pager pager=new Pager();
        pager.setPageNum(pageNum);
        pager.setPageSize(6);

        ScheduleDAO scheduleDAO=new ScheduleDAO();
        List<Schedule> schedules;
        if (movieName != null && !movieName.isEmpty()) {
            // 如果有电影名，则根据电影名查询
            schedules = scheduleDAO.findBymovieName(movieName, pager);
        } else {
            // 否则，查询所有场次
            schedules = scheduleDAO.findByPager(pager);
        }

        model.addAttribute("schedules",schedules);

        return "manage/scheduleList";
    }
    //添加场次
    @RequestMapping("addSchedule")
    public String addSchedule(String[] movieSelect,String moviehallSelect,String showDateInput,String[] timeSelect){
        ScheduleDAO scheduleDAO = new ScheduleDAO();
        List<Schedule> schedules=new ArrayList<>();
        for(int i=0;i<movieSelect.length;i++)
        {
            Movie movie=scheduleDAO.addmovieId(movieSelect[i]);
            Moviehall moviehall=scheduleDAO.addmoviehallId(moviehallSelect);
            if(movie!=null&&moviehall!=null)
            {
                Schedule schedule=new Schedule();
                schedule.setMovieId(movie.getMovieId());
                schedule.setMovieHallId(moviehall.getMovieHallId());
                schedule.setScheduleDate(Date.valueOf(showDateInput));
                schedule.setScheduleTime(Time.valueOf(timeSelect[i]));
                schedules.add(schedule);
            }
        }
        scheduleDAO.addSchedule(schedules);
        return "redirect:/manage/scheduleDesign";
    }
    // 修改场次
    @RequestMapping("updateSchedule")
    public String updateSchedule(String movieSelect, String timeSelect, HttpServletRequest request) {
        ScheduleDAO scheduleDAO = new ScheduleDAO();
        Movie movie = scheduleDAO.addmovieId(movieSelect);
        Integer scheduleId = Integer.parseInt(request.getParameter("scheduleId"));

        // 检查时间格式是否为 HH:MM:SS
        if (!isValidTimeFormat(timeSelect)) {
            return "redirect:/manage/scheduleDesign";
        }

        // 检查新开场时间是否超过23:00
        LocalTime newStartTime = LocalTime.parse(timeSelect);
        if (newStartTime.isAfter(LocalTime.of(23, 0))) {

            return "redirect:/manage/scheduleDesign";
        }

        // 更新当前电影信息
        scheduleDAO.updateSchedule(movie.getMovieId(), Time.valueOf(timeSelect), scheduleId);

        // 获取当前电影的放映厅Id, 放映日期, 播放时长
        List<Schedule> schedules = scheduleDAO.getHallIdByScheduleId(scheduleId);
        Integer movieHallId = schedules.get(0).getMovieHallId();
        Date scheduleDate = schedules.get(0).getScheduleDate();
        String currentDuration = schedules.get(0).getMovie().getDuration();

        // 查询该放映厅下的所有后续电影
        List<Schedule> subsequentSchedules = scheduleDAO.getSubsequentSchedules(movieHallId, scheduleDate, Time.valueOf(timeSelect));

        // 计算新的开场时间并更新后续电影
        String updatedStartTime = timeSelect; // 新开场时间从当前电影的开场时间开始
        for (Schedule schedule : subsequentSchedules) {
            // 计算新的开场时间
            updatedStartTime = calculateNewStartTime(updatedStartTime, Integer.parseInt(currentDuration));

            // 检查是否返回了 null
            if (updatedStartTime == null) {
                return "redirect:/manage/scheduleDesign"; // 或者重定向到错误页面
            }

            // 更新数据库
            scheduleDAO.updateSchedule(schedule.getMovieId(), Time.valueOf(updatedStartTime), schedule.getScheduleId());

            // 更新当前电影的播放时长
            currentDuration = schedule.getMovie().getDuration(); // 获取下一场电影的播放时长
        }

        return "redirect:/manage/scheduleDesign";
    }

    // 验证时间格式是否为 HH:MM:SS
    private boolean isValidTimeFormat(String time) {
        String timePattern = "^([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)$"; // 正则表达式匹配 HH:MM:SS
        return Pattern.matches(timePattern, time);
    }

        // 计算新的开场时间的辅助方法
    private String calculateNewStartTime(String previousStartTime, int duration) {
        String[] parts = previousStartTime.split(":");
        LocalTime time = LocalTime.of(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), Integer.parseInt(parts[2]));
        time = time.plusMinutes(duration + 10); // 加上播放时长和10分钟的休息时间

        // 检查是否超过23:00
        if (time.isAfter(LocalTime.of(23, 0))) {
            return null; // 返回null表示超过23:00:00
        }

        // 返回 HH:MM:SS 格式
        return String.format("%02d:%02d:%02d", time.getHour(), time.getMinute(), time.getSecond());
    }



    //删除单个场次
    @RequestMapping("deleteByScheduleId")
    public String deleteByScheduleId(HttpServletRequest request) {
        Integer scheduleId = Integer.parseInt(request.getParameter("scheduleId"));
        Schedule schedule = new Schedule();
        schedule.setScheduleId(scheduleId);
        schedule.setStatus(false);

        ScheduleDAO scheduleDAO = new ScheduleDAO();
        scheduleDAO.deleteByScheduleId(schedule);

        return "redirect:/manage/scheduleDesign";
    }
    //删除复选框选中的场次
    @RequestMapping("deleteScheduleMore")
    public String deleteScheduleMore(Integer[] scheduleIds)
    {
        ScheduleDAO scheduleDAO=new ScheduleDAO();
        for (Integer scheduleId:scheduleIds)
        {
            Schedule schedule=new Schedule();
            schedule.setScheduleId(scheduleId);
            schedule.setStatus(false);
            scheduleDAO.deleteByScheduleId(schedule);
        }
        return "redirect:/manage/scheduleDesign";
    }
}
