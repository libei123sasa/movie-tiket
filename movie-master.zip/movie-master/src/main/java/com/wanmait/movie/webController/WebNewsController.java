package com.wanmait.movie.webController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("web")
public class WebNewsController {
    @RequestMapping("news")
    public String news(){
        return "web/news";
    }
}
