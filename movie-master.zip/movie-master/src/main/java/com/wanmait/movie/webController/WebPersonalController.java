package com.wanmait.movie.webController;

import com.wanmait.movie.dao.PersonDao;
import com.wanmait.movie.dao.UserinfoDAO;
import com.wanmait.movie.vo.MovieOrder;
import com.wanmait.movie.vo.Userinfo;
import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.jsf.FacesContextUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping("web")
public class WebPersonalController {
    @RequestMapping("personalCenter")
    public String personalCenter(Model model,HttpServletRequest request)
    {
        HttpSession session=request.getSession();
        Object user=session.getAttribute("userinfo");
        Userinfo userinfo=(Userinfo) user;

        PersonDao personDao=new PersonDao();
       // System.out.println(userinfo.getUserid());
        List<MovieOrder> movieOrders=personDao.findMovieOrder(userinfo.getUserid());
       // System.out.println(movieOrders);
        model.addAttribute("movieOrders",movieOrders);


        return "web/personalCenter";
    }
    @RequestMapping("updatePersonal")
    public String updatePersonal(Userinfo userinfo, MultipartFile face, HttpServletRequest request)
    {
        String filename ="";
        if(!face.isEmpty())//选择文件
        {
            //获得/static/uploadImages文件夹的绝对路径
            String filepath = request.getServletContext().getRealPath("/static/uploadImages");

            //获得源文件名
            String originalFilename = face.getOriginalFilename();
            //获得扩展名
            String extension = FilenameUtils.getExtension(originalFilename);

            //新文件名
            filename = UUID.randomUUID().toString() + "." + extension;

            //保存
            try {
                face.transferTo(new File(filepath + "/" + filename));
            } catch (IOException e) {
                e.printStackTrace();
            }
            LocalDateTime now = LocalDateTime.now();
            Timestamp timestamp = Timestamp.valueOf(now);
            // 转换为 java.sql.Timestamp
            userinfo.setUpdateTime(timestamp);
            userinfo.setUserPhoto(filename);
        }

        UserinfoDAO userinfoDAO = new UserinfoDAO();
        userinfoDAO.updateByUserId(userinfo);
        HttpSession session = request.getSession();
        session.invalidate();
        return "redirect:/web/exit";
    }
    //取消订单
    @RequestMapping("cancel")
    @ResponseBody
    public String cancel(String cancelValue,HttpServletRequest request,Model model)
    {
        PersonDao personDao =new PersonDao();
        MovieOrder movieOrder=personDao.findPayTime(cancelValue);
        // 获取下单时间
        LocalDateTime payTime = movieOrder.getPayTime().toLocalDateTime();
        //当前系统时间
        LocalDateTime currentTime = LocalDateTime.now();
        // 计算时间差
        long minutesDiff = ChronoUnit.MINUTES.between(payTime, currentTime);

        if (minutesDiff > 30) {
            return "1"; // 返回提示信息
        }
        else
        {
            //删除
            MovieOrder movieOrder1=personDao.findBy(cancelValue);
            personDao.deleteCancel(movieOrder1);

            return "0";
        }
    }
}
