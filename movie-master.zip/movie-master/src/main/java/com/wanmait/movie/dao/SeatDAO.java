package com.wanmait.movie.dao;

import com.wanmait.movie.util.JDBCDruidUtils;
import com.wanmait.movie.vo.Seat;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.List;

public class SeatDAO {
    public int[][] findSeatsByScheduleid(int scheduleId) {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "SELECT `ROW`, col FROM order_seat WHERE scheduleid = ? and status = 1 ORDER BY `row` ASC , col ASC;";

        try
        {
            List<Seat> seats = queryRunner.query(sql, new BeanListHandler<>(Seat.class), scheduleId);
            // 将List转换为二维数组
            int[][] seatsArray = new int[seats.size()][2];
            for (int i = 0; i < seats.size(); i++) {
                Seat seat = seats.get(i);
                seatsArray[i][0] = seat.getRow();
                seatsArray[i][1] = seat.getCol();
            }
            return seatsArray;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
