package com.wanmait.movie.manageController;

import com.wanmait.movie.dao.MovieDAO;
import com.wanmait.movie.dao.SortMovieDAO;
import com.wanmait.movie.vo.Movie;
import com.wanmait.movie.vo.Pager;
import com.wanmait.movie.vo.Sort;
import com.wanmait.movie.vo.SortMovie;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Controller
@RequestMapping("manage")
public class ManageSortMovieDesignController {

    @RequestMapping("sortMovieDesign")
    public String sortMovieDesign(HttpSession session ,Model model)

    {
        SortMovieDAO sortMovieDAO = new SortMovieDAO();
        List<Movie> allMovie = sortMovieDAO.getAllMovie();
        List<Sort> allSort = sortMovieDAO.getAllSort();

        Pager pager = new Pager();
        pager.setPageNum(1);
        pager.setPageSize(6);

        List<SortMovie> allSortMovieAndMovieAndSort = sortMovieDAO.findByPager(pager);
        model.addAttribute("allSortMovieAndMovieAndSort",allSortMovieAndMovieAndSort);

        //总页数
        Integer total = sortMovieDAO.findTotal();
        Integer pageCount = total/ pager.getPageSize()+(total% pager.getPageSize()==0?0:1);
        pager.setPageCount(pageCount);

        model.addAttribute("pager",pager);

        session.setAttribute("allMovie",allMovie);
        session.setAttribute("allSort",allSort);
        return "manage/sortMovieDesign";
    }

    @RequestMapping("addSortMovie")
    public String addSortMovie(SortMovie sortMovie,Integer[] sortids)
    {
        for(Integer sortid:sortids)
        {
            sortMovie.setSortsid(sortid);
            SortMovieDAO sortMovieDAO = new SortMovieDAO();

            LocalDateTime now = LocalDateTime.now();
            Timestamp timestamp = Timestamp.valueOf(now);
            // 转换为 java.sql.Timestamp
            sortMovie.setUpdateTime(timestamp);
            sortMovieDAO.addSortMovie(sortMovie);
        }

        return "redirect:/manage/sortMovieDesign";
    }

    @RequestMapping("isSortMovieExist")
    @ResponseBody
    public String isSortMovieExist(SortMovie sortMovie, int[] sortsid)
    {

        SortMovieDAO sortMovieDAO = new SortMovieDAO();
        SortMovie sortMovieExist = sortMovieDAO.ifSortMovieExist(sortMovie);
        if (sortMovieExist!=null)
        {
            return "1";
        }
        else {
            return "0";
        }
    }

    //查询所有电影所属分类  分页
    @RequestMapping("showAll")
    public String showAll(Model model)
    {

        return "manage/sortMovieDesign";

    }

    //删除单个电影所属分类
    @RequestMapping("deleteBymovieid")
    public String deleteBymovieid(HttpServletRequest request)
    {
        SortMovieDAO sortMovieDAO = new SortMovieDAO();
        int movieId = Integer.parseInt(request.getParameter("movieId"));
        SortMovie sortMovie = new SortMovie();
        sortMovie.setMovieid(movieId);
        //获取当前时间
        LocalDateTime now = LocalDateTime.now();
        Timestamp timestamp = Timestamp.valueOf(now);
        // 转换为 java.sql.Timestamp
        sortMovie.setUpdateTime(timestamp);// 转换为 java.sql.Date
        sortMovie.setStatus(false);

        sortMovieDAO.deleteByMovieId(sortMovie);
        return "redirect:/manage/sortMovieDesign";
    }

    //批量删除
    @RequestMapping("deleteMoreSortMovie")
    public String deleteMore(Integer[] movieIds)
    {
        SortMovieDAO sortMovieDAO = new SortMovieDAO();
        for(Integer movieId:movieIds)
        {
            SortMovie sortMovie = new SortMovie();
            sortMovie.setMovieid(movieId);
            //获取当前时间
            LocalDateTime now = LocalDateTime.now();
            Timestamp timestamp = Timestamp.valueOf(now);
            // 转换为 java.sql.Timestamp
            sortMovie.setUpdateTime(timestamp);
            sortMovie.setStatus(false);

            sortMovieDAO.deleteByMovieId(sortMovie);
        }
        return "redirect:/manage/sortMovieDesign";
    }

    //根据电影名查询
    @RequestMapping("findSortMovieByMovieName")
    public String findByMovieName(String movieName,Model model)
    {
        SortMovieDAO sortMovieDAO = new SortMovieDAO();
        List<SortMovie> sortMovieByMovieName = sortMovieDAO.findSortMovieByMovieName(movieName);
        model.addAttribute("allSortMovieAndMovieAndSort",sortMovieByMovieName);

        Pager pager = new Pager();
        pager.setPageNum(1);
        pager.setPageSize(6);

        Integer total = sortMovieDAO.findTotal();
        Integer pageCount = 1;
        pager.setPageCount(pageCount);
        model.addAttribute("pager",pager);
        return "manage/sortMovieDesign";
    }

    //Ajax
    @RequestMapping("sortMovieChange")
    public String sortMovieChange(Integer pageNum,Model model)
    {
        Pager pager = new Pager();
        pager.setPageNum(pageNum);
        pager.setPageSize(6);
        SortMovieDAO sortMovieDAO = new SortMovieDAO();
        List<SortMovie> allSortMovieAndMovieAndSort = sortMovieDAO.findByPager(pager);
        model.addAttribute("allSortMovieAndMovieAndSort",allSortMovieAndMovieAndSort);

        return "manage/sortMovieList";
    }
}
