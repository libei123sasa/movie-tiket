package com.wanmait.movie.vo;

import lombok.Data;

import java.sql.Date;
import java.sql.Timestamp;

@Data
public class Movie {
    private int movieId;//电影id
    private String movieName;//电影名
    private String moviePhoto;//电影图片
    private String director;//导演
    private String mainPerformer;//主要演员
    private String duration;//时长
    private String area;//区域
    private Date releaseDate;//上映日期
    private float price;//票价
    private String opera;//剧情简介
    private Timestamp updateTime;//最近修改时间
    private boolean status;//电影状态

}
