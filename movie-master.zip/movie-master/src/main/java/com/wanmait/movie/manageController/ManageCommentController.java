package com.wanmait.movie.manageController;

import com.wanmait.movie.dao.CommentDAO;
import com.wanmait.movie.vo.Commentt;
import com.wanmait.movie.vo.Pager;
import com.wanmait.movie.vo.Senstive;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("manage")
public class ManageCommentController
{
    //评论页面,显示第一页数据
    @RequestMapping  ("commentDesign")
    public void commentDesign(Model model)
    {
        Pager pager=new Pager();
        pager.setPageNum(1);
        pager.setPageSize(6);

        CommentDAO commentDAO=new CommentDAO();
        List<Commentt> commentts=commentDAO.findByPager(pager);

        model.addAttribute("commentts",commentts);

        //总页数
        Integer total=commentDAO.findTotal();
        Integer pageCount=total/pager.getPageSize()+(total%pager.getPageSize()==0?0:1);
        pager.setPageCount(pageCount);
        model.addAttribute("pager",pager);

        // 获取敏感词并添加到模型
        List<Senstive> sensitiveWords =commentDAO.findBySenstive();
        model.addAttribute("sensitiveWords", sensitiveWords);
    }
    //Ajax
    @RequestMapping("commentChange")
    public String commentChange(Integer pageNum,Model model,String username)
    {
            Pager pager=new Pager();
            pager.setPageNum(pageNum);
            pager.setPageSize(6);

            CommentDAO commentDAO=new CommentDAO();
            List<Commentt> commentts=null;
            if(username!=null&&!username.isEmpty())
            {
                //如果有用户名，根据用户名查询
                commentts=commentDAO.findByUsername(username,pager);
            }
            else
            {
                // 否则，查询所有场次
                commentts=commentDAO.findByPager(pager);
            }

            model.addAttribute("commentts",commentts);

            // 获取敏感词并添加到模型
            List<Senstive> sensitiveWords =commentDAO.findBySenstive();
            model.addAttribute("sensitiveWords", sensitiveWords);

            return "manage/commentList";
    }

    //删除复选框选中的评论
    @RequestMapping("deleteCommentMore")
    public String deleteCommentMore(Integer[] commentIds)
    {
        CommentDAO commentDAO=new CommentDAO();
        for (Integer commentId: commentIds)
        {
            Commentt commentt=new Commentt();
            commentt.setCommentId(commentId);
            commentt.setStatus(false);
            commentDAO.deleteByCommentId(commentt);
        }
        return "redirect:/manage/commentDesign";
    }
    //删除单个场次
    @RequestMapping("deleteBycommentId")
    public String deleteBycommentId(HttpServletRequest request)
    {
        Integer commentId=Integer.parseInt(request.getParameter("commentId"));
        Commentt commentt=new Commentt();
        commentt.setCommentId(commentId);
        commentt.setStatus(false);

        CommentDAO commentDAO=new CommentDAO();
        commentDAO.deleteByCommentId(commentt);
        return "redirect:/manage/commentDesign";
    }
    //根据用户名查询评论
    @PostMapping("AlsofindByUsername")
    public String AlsofindByUsername(String username,Model model,HttpServletResponse response)
    {
        Pager pager=new Pager();
        pager.setPageNum(1);
        pager.setPageSize(6);

        CommentDAO commentDAO=new CommentDAO();

        //根据用户名查询评论的总页数
        Integer total=commentDAO.CountByUsername(username);
        Integer pageCount=total/pager.getPageSize()+(total%pager.getPageSize()==0?0:1);
        pager.setPageCount(pageCount);
        model.addAttribute("pager",pager);

        List<Commentt> commentts=commentDAO.findByUsername(username,pager);
        if(commentts!=null)
        {
            model.addAttribute("commentts",commentts);
        }
        else
        {
            model.addAttribute("commentts",new ArrayList<>());
        }
        //将username存到model
        model.addAttribute("username",username);

        return "manage/commentDesign";
    }
}
