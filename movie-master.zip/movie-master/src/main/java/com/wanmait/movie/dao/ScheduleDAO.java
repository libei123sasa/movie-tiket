package com.wanmait.movie.dao;

import com.wanmait.movie.util.JDBCDruidUtils;
import com.wanmait.movie.vo.*;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ScheduleDAO
{
    //查询某页数据
    public List<Schedule> findByPager(Pager pager)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        List<Schedule> schedules=new ArrayList<>();
        String sql="select scheduleId,movie.movieName,moviehall.movieHallName,scheduleDate,scheduleTime " +
                "from schedule,movie,moviehall where schedule.movieId=movie.movieId " +
                "and schedule.moviehallid = moviehall.moviehallid and schedule.status=1 limit ?,?";
        try{
            List<Map<String,Object>> mapList=queryRunner.query(sql,new MapListHandler(),(pager.getPageNum()-1)* pager.getPageSize(),pager.getPageSize());
            for(Map<String,Object> map:mapList)
            {
                Schedule schedule=new Schedule();
                schedule.setScheduleId((Integer)map.get("scheduleId"));
                schedule.setMovieId((Integer) map.get("movieId"));
                schedule.setMovieHallId((Integer) map.get("movieHallId"));
                schedule.setScheduleDate((Date) map.get("scheduleDate"));
                schedule.setScheduleTime((Time) map.get("scheduleTime"));

                Movie movie=new Movie();
                movie.setMovieName((String) map.get("movieName"));

                Moviehall moviehall=new Moviehall();
                moviehall.setMovieHallName((String) map.get("movieHallName"));

                schedule.setMovie(movie);
                schedule.setMoviehall(moviehall);

                schedules.add(schedule);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return schedules;
    }
    //总数
    public Integer findTotal()
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select count(*) from schedule where status=1";
        try {
            Object object=queryRunner.query(sql,new ScalarHandler());
            return Integer.parseInt(object.toString());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }
    //查询所有电影
    public List<Movie> findMovies()
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select * from movie where status=1 and releaseDate < curdate()";
        try {
            List<Movie> movies=queryRunner.query(sql,new BeanListHandler<>(Movie.class));
            return movies;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }
    //查询所有放映厅
    public List<Moviehall> findMoviehalls()
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select movieHallName from moviehall where status=1";
        try {
            List<Moviehall> moviehalls=queryRunner.query(sql,new BeanListHandler<>(Moviehall.class));
            return moviehalls;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }

    //添加场次
    public Movie addmovieId(String movieSelect)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        //获取movieId
        String movieSql="select movieId from movie where movieName=?";
        Movie movie=null;
        try {
            movie=queryRunner.query(movieSql,new BeanHandler<>(Movie.class),movieSelect);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return movie;
    }
    public Moviehall addmoviehallId(String moviehallSelect)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        //获取moviehallId
        String moviehallIdSql="select movieHallId from moviehall where movieHallName=?";
        Moviehall moviehall=null;
        try {
            moviehall=queryRunner.query(moviehallIdSql,new BeanHandler<>(Moviehall.class),moviehallSelect);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return moviehall;
    }
    public void addSchedule(List<Schedule> schedules)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        //插入到schedule
        String sql="insert into schedule(movieId,movieHallId,scheduleDate,scheduleTime) values(?,?,?,?)";
        Object[][] params=new Object[schedules.size()][4];
        for (int i=0;i<schedules.size();i++)
        {
            params[i][0]=schedules.get(i).getMovieId();
            params[i][1]=schedules.get(i).getMovieHallId();
            params[i][2]=schedules.get(i).getScheduleDate();
            params[i][3]=schedules.get(i).getScheduleTime();
        }
        try {
            queryRunner.batch(sql, params);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    //修改场次
    public void updateSchedule(Integer editMovieId,java.sql.Time timeSelect,Integer scheduleId)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        //插入到schedule
        String sql="update schedule set movieId=?,scheduleTime=? where scheduleId=?";
        try{
            queryRunner.update(sql,editMovieId,timeSelect,scheduleId);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    //删除单个场次
    public void deleteByScheduleId(Schedule schedule)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="update schedule set status=? where scheduleId=?";
        try {
            queryRunner.update(sql,schedule.isStatus(),schedule.getScheduleId());

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    //根据电影名查询
    public List<Schedule> findBymovieName(String movieName,Pager pager)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        List<Schedule> schedules=new ArrayList<>();
        String sql="select scheduleId,movie.movieName, moviehall.movieHallName, scheduleDate, scheduleTime " +
                "from movie, moviehall, schedule " +
                "where movie.movieId = schedule.movieId " +
                "and moviehall.movieHallId = schedule.movieHallId " +
                "and schedule.status = 1 " +
                "and movie.movieName = ? " +
                "limit ?,?";
        try {
            List<Map<String,Object>> mapList=queryRunner.query(sql,new MapListHandler(),movieName,(pager.getPageNum()-1)* pager.getPageSize(),pager.getPageSize());
            for(Map<String,Object> map:mapList)
            {
                Schedule schedule=new Schedule();
                schedule.setScheduleId((Integer)map.get("scheduleId"));
                schedule.setScheduleDate((Date) map.get("scheduleDate"));
                schedule.setScheduleTime((Time) map.get("scheduleTime"));

                Movie movie=new Movie();
                movie.setMovieName((String) map.get("movieName"));

                Moviehall moviehall=new Moviehall();
                moviehall.setMovieHallName((String) map.get("movieHallName"));

                schedule.setMovie(movie);
                schedule.setMoviehall(moviehall);

                schedules.add(schedule);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return schedules;
    }
    //查找符合电影名的总记录数
    public Integer CountBymovieName(String movieName)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select count(*) from schedule,movie where schedule.movieId=movie.movieId and schedule.status=1 and movie.movieName=?";
        try {
            Object object=queryRunner.query(sql,new ScalarHandler(),movieName);
            return Integer.parseInt(object.toString());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }
    //根据电影id查询场次
    public List<Schedule> findScheduleByMovieId(Integer movieId)
    {
        List<Schedule> schedules=new ArrayList<>();
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="SELECT movie.movieName,movie.price,movieHallName,moviehall.movieHallId,scheduleId,scheduleTime,scheduleDate FROM movie,moviehall,schedule WHERE moviehall.movieHallId=schedule.movieHallId and schedule.movieId=movie.movieId AND schedule.status=1 and scheduleDate=CURDATE() AND schedule.movieId=?";
        try {
            List<Map<String,Object>> mapList=queryRunner.query(sql,new MapListHandler(),movieId);
            for(Map<String,Object> map:mapList)
            {
                Schedule schedule=new Schedule();
                schedule.setScheduleId((Integer)map.get("scheduleId"));
                schedule.setScheduleDate((Date) map.get("scheduleDate"));
                schedule.setScheduleTime((Time) map.get("scheduleTime"));

                Moviehall moviehall=new Moviehall();
                moviehall.setMovieHallId((int) map.get("movieHallId"));
                moviehall.setMovieHallName((String) map.get("movieHallName"));

                Movie movie = new Movie();
                movie.setPrice((float) map.get("price"));
                movie.setMovieName((String) map.get("movieName"));
                schedule.setMoviehall(moviehall);
                schedule.setMovie(movie);
                schedules.add(schedule);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return schedules;
    }
    //根据电影id和日期查询第二天天场次
    public List<Schedule> findToScheduleByMovieId(Integer movieId)
    {
        List<Schedule> schedules=new ArrayList<>();
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="SELECT moviehall.movieHallId,movie.price,movieHallName,scheduleId,scheduleTime,scheduleDate,movieName FROM moviehall,schedule, movie WHERE moviehall.movieHallId=schedule.movieHallId AND schedule.movieId=movie.movieId AND schedule.status=1 and  scheduleDate = DATE_ADD(CURDATE(), INTERVAL 1 DAY) AND schedule.movieId=?";
        try {
            List<Map<String,Object>> mapList=queryRunner.query(sql,new MapListHandler(),movieId);
            for(Map<String,Object> map:mapList)
            {
                Schedule schedule=new Schedule();
                schedule.setScheduleId((Integer)map.get("scheduleId"));
                schedule.setScheduleDate((Date) map.get("scheduleDate"));
                schedule.setScheduleTime((Time) map.get("scheduleTime"));

                Moviehall moviehall=new Moviehall();
                moviehall.setMovieHallId((int) map.get("movieHallId"));
                moviehall.setMovieHallName((String) map.get("movieHallName"));

                Movie movie = new Movie();
                movie.setPrice((float) map.get("price"));
                movie.setMovieName((String) map.get("movieName"));
                schedule.setMoviehall(moviehall);
                schedule.setMovie(movie);
                schedules.add(schedule);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return schedules;
    }
    //根据放映厅和发映日期查询电影
    public Moviehall findByMovieHallName(String movieHallName)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select movieHallId from moviehall where status=1 and movieHallName=?";
        try {
            Moviehall moviehall=queryRunner.query(sql,new BeanHandler<>(Moviehall.class),movieHallName);
            return  moviehall;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }
    public List<Schedule> findByMovieHallNameAndDate(Integer movieHallId,Date scheduleDate)
    {
        List<Schedule> schedules=new ArrayList<>();
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select movieName,duration,scheduleDate,scheduleTime from movie,schedule where movie.movieId=schedule.movieId and schedule.status=1 and movieHallId=? and scheduleDate=?";
            try{
                List<Map<String,Object>> mapList=queryRunner.query(sql,new MapListHandler(),movieHallId,scheduleDate);
                for(Map<String,Object> map:mapList)
                {
                    Schedule schedule=new Schedule();

                    Movie movie = new Movie();
                    movie.setMovieName((String) map.get("movieName"));
                    movie.setDuration((String) map.get("duration") );
                    schedule.setMovie(movie);
                    schedule.setScheduleDate((Date) map.get("scheduleDate"));
                    schedule.setScheduleTime((Time) map.get("scheduleTime"));
                    schedules.add(schedule);
                }
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            return schedules;
    }
//获取当前电影的放映厅Id，放映日期,播放时长
    public List<Schedule> getHallIdByScheduleId(Integer scheduleId)
    {
        List<Schedule> schedules=new ArrayList<>();
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select movieHallId,scheduleDate,duration from schedule,movie where schedule.movieId=movie.movieId and schedule.status=1 and scheduleId=?";
        try{
            List<Map<String,Object>> mapList=queryRunner.query(sql,new MapListHandler(),scheduleId);
            for(Map<String,Object> map:mapList)
            {
                Schedule schedule=new Schedule();

                Movie movie = new Movie();
                movie.setDuration((String) map.get("duration") );
                schedule.setMovie(movie);
                schedule.setMovieHallId((Integer) map.get("movieHallId"));
                schedule.setScheduleDate((Date) map.get("scheduleDate"));
                schedules.add(schedule);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return schedules;
    }
    // 查询该放映厅下的所有后续电影
    public List<Schedule> getSubsequentSchedules(Integer movieHallId,Date scheduleDate,Time timeSelect)
    {
        List<Schedule> schedules=new ArrayList<>();
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select schedule.movieId,scheduleId,movie.duration from schedule,movie where movie.movieId=schedule.movieId and scheduleDate=? and scheduleTime>? and movieHallId=?";
        try{
            List<Map<String,Object>> mapList=queryRunner.query(sql,new MapListHandler(),scheduleDate,timeSelect,movieHallId);
            for(Map<String,Object> map:mapList)
            {
                Schedule schedule=new Schedule();

                Movie movie = new Movie();
                movie.setDuration((String) map.get("duration") );
                schedule.setMovie(movie);
                schedule.setMovieId((Integer) map.get("movieId"));
                schedule.setScheduleId((Integer) map.get("scheduleId"));
                schedules.add(schedule);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return schedules;
    }
    //根据场次id查询该场次开场时间
    public Schedule findScheduleTime(Integer scheduleId)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select scheduleDate,scheduleTime from schedule where scheduleId=? and status=1";
        try {
            Schedule schedule=queryRunner.query(sql,new BeanHandler<>(Schedule.class),scheduleId);
            return schedule;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }
}
