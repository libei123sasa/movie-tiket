package com.wanmait.movie.manageController;

import com.wanmait.movie.dao.SortDAO;
import com.wanmait.movie.dao.UserinfoDAO;
import com.wanmait.movie.util.JDBCDruidUtils;
import com.wanmait.movie.vo.Pager;
import com.wanmait.movie.vo.Question;
import com.wanmait.movie.vo.Sort;
import com.wanmait.movie.vo.Userinfo;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

@ControllerAdvice
@RequestMapping("manage")
public class ManageMovieClassDesignController
{
    //根据电影分类查询
    @RequestMapping("getByMovie")
    public String getByMovie(String sorts,Model model)
    {
        Pager pager = new Pager();
        pager.setPageNum(1);
        pager.setPageSize(6);

        SortDAO sortDAO = new SortDAO();

        Integer total = sortDAO.coimtByMovie(sorts);
        Integer pageCount = total/pager.getPageSize()+(total%pager.getPageSize()==0?0:1);
        pager.setPageCount(pageCount);

        model.addAttribute("pager",pager);

        Sort sort = sortDAO.getByMovie(sorts);
        if(sort!=null)
        {
            List<Sort> sortList = new ArrayList<>();
            sortList.add(sort); // 将单个分类添加到 ArrayList
            model.addAttribute("sortList", sortList);
        }
        else
        {
            // 分类不存在，可以返回一个空的列表或相应的提示
            model.addAttribute("sortList", new ArrayList<>()); // 返回空列表
        }
        return "/manage/sortDesign"; // 返回管理页面
    }


    //添加电影分类
    @RequestMapping("addMovies")
    public String addMovies(Sort sort)
    {
        SortDAO sortDAO = new SortDAO();
        sortDAO.findMovie(sort);
        return "redirect:/manage/movieclassDesign";
    }

    //判断电影分是否存在
    @RequestMapping("isSort")
    @ResponseBody
    public String isSort(String sortsname)
    {
        SortDAO sortDAO = new SortDAO();
        Sort sort1 = sortDAO.getByMovie2(sortsname);
        if(sort1!=null)
        {
            //电影已存在
            return "1";
        }
        else {
            return "0";
        }
    }

    //删除单个电影分类
    @RequestMapping("moitMovie")
    public String moitMovie(HttpServletRequest request)
    {
        int id = Integer.parseInt(request.getParameter("id"));
        SortDAO sortDAO = new SortDAO();
        Sort sort = new Sort();
        sort.setId(id);
        sort.setStatus(false);

        sortDAO.omitMovie(sort);
        return  "redirect:/manage/movieclassDesign";
    }

    //批量删除电影分类
    @RequestMapping("shanMovie")
    public String shanMovie(Integer[] ids)
    {
        SortDAO sortDAO = new SortDAO();
        for (int i = 0; i < ids.length; i++) {
            Sort sort = new Sort();
            sort.setId(ids[i]);
            sort.setStatus(false);

            sortDAO.omitMovie(sort);
        }
        return  "redirect:/manage/movieclassDesign";
    }

    //跳转到sortDesign页面并查询出所有分类
    //设置页码
    @RequestMapping("movieclassDesign")
    public String movieclassDesign(Integer pageNum,Model model)
    {
        Pager pager = new Pager();
        SortDAO sortDAO = new SortDAO();
        if(pageNum==null)
        {
            pageNum=1;
        }
        pager.setPageNum(pageNum);
        pager.setPageSize(6);
        Integer total = sortDAO.findTotal();
        Integer pageCount = total/pager.getPageSize()+(total%pager.getPageSize()==0?0:1);
        pager.setPageCount(pageCount);
        List<Sort> sortList = sortDAO.getAll(pager);
        model.addAttribute("sortList",sortList);
        model.addAttribute("pager",pager);
        return "manage/sortDesign";
    }

    //Ajax
    @GetMapping ("sort2")
    public String sort2(Integer pageNum,Model model)
    {
        Pager pager = new Pager();
        pager.setPageNum(pageNum);
        pager.setPageSize(6);
        SortDAO sortDAO = new SortDAO();
        List<Sort> sortList = sortDAO.getAll(pager);
        model.addAttribute("sortList",sortList);
        return "manage/sortDesign2";
    }

}