package com.wanmait.movie.webController;

import com.wanmait.movie.dao.LunbotuDAO;
import com.wanmait.movie.vo.LunBoTu;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("web")
public class WebLunBoTuController {
    @RequestMapping("lunbotu")
    @ResponseBody
    public List<String> LunBoTu()
    {
        LunbotuDAO lunbotuDAO = new LunbotuDAO();
        List<LunBoTu> image = lunbotuDAO.findImage();
        List<String> src = new ArrayList<>();
        for (int i = 0; i < image.size(); i++) {
            src.add(image.get(i).getSrc());
        }
        return src;
    }
}
