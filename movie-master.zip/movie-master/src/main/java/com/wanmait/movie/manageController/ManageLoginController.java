package com.wanmait.movie.manageController;

import com.wanmait.movie.dao.AdminDAO;
import com.wanmait.movie.util.CookieUtils;
import com.wanmait.movie.vo.Admininfo;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@ControllerAdvice
@RequestMapping("manage")
public class ManageLoginController
{
    @RequestMapping("login")
    public String login()
    {
        return "manage/login";
    }

    @RequestMapping("checkadmin")
    public String checkadmin(Admininfo admininfo,String AutoLogin, HttpSession session, HttpServletResponse response)
    {
        AdminDAO adminDAO=new AdminDAO();
        Admininfo adminLogin=adminDAO.findByadname(admininfo.getAdname());
        if(adminLogin==null)
        {
            return "redirect:/manage/login?err=1";
        }
        else
        {
            if(adminLogin.getAdpwd().equals(admininfo.getAdpwd()))
            {
                session.setAttribute("adminLogin",adminLogin);

                if("1".equals(AutoLogin))
                {
                    //保存到cookie
                    Cookie cookie=new Cookie("adname",adminLogin.getAdname());
                    cookie.setMaxAge(30*24*60*60);
                    cookie.setPath("/");
                    response.addCookie(cookie);

                    CookieUtils.createCookie("adpwd",admininfo.getAdpwd(),30*24*60*60,"/",response);
                }
                return "redirect:/manage/index";
            }
            else
            {
                return "redirect:/manage/login?err=1";
            }
        }
    }

    @RequestMapping("exit")
    public String exit(HttpSession session,HttpServletResponse response)
    {
        session.invalidate();
        CookieUtils.createCookie("adname",null,0,"/",response);
        CookieUtils.createCookie("adpwd",null,0,"/",response);
        return "redirect:/manage/login";
    }
}

