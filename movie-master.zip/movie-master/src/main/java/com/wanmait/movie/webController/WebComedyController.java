package com.wanmait.movie.webController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("web")
public class WebComedyController {
    @RequestMapping("comedy")
    public String comedy(){
        return "web/comedy";
    }
}
