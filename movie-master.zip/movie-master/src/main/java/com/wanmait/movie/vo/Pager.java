package com.wanmait.movie.vo;

import lombok.Data;

@Data
public class Pager {
    private Integer pageNum;//第几页
    private Integer pageSize;//每页多少条数据
    private Integer pageCount;//总页数
}
