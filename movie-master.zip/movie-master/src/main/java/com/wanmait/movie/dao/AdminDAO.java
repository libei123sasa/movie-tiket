package com.wanmait.movie.dao;

import com.wanmait.movie.util.JDBCDruidUtils;
import com.wanmait.movie.vo.Admininfo;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import java.sql.SQLException;

public class AdminDAO
{
    public Admininfo findByadname(String adname)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select*from admininfo where adname=?";
        try {
            Admininfo admininfo = queryRunner.query(sql,new BeanHandler<>(Admininfo.class),adname);
            return admininfo;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }
    public void update(Admininfo admininfo)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "UPDATE admininfo SET adpwd = ? WHERE id = ?";
        try {
            queryRunner.update(sql,admininfo.getAdpwd(),admininfo.getId());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
