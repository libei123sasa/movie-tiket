package com.wanmait.movie.vo;

import lombok.Data;

@Data
public class Senstive
{
    private Integer senstiveId;
    private String words;
}
