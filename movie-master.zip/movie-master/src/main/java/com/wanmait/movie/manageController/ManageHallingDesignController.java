package com.wanmait.movie.manageController;

import com.wanmait.movie.dao.MoviehallDAO;
import com.wanmait.movie.vo.Moviehall;
import com.wanmait.movie.vo.Pager;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

@ControllerAdvice
@RequestMapping("manage")
public class ManageHallingDesignController
{
    @RequestMapping("hallingDesign")
    //跳转到hallDesign页面并查询出所有用户数据
    //设置页码
    public String hallDesign(Model model)
    {

        Pager pager = new Pager();
        pager.setPageNum(1);
        pager.setPageSize(5);

        MoviehallDAO moviehallDAO = new MoviehallDAO();
        List<Moviehall> moviehalls=moviehallDAO.findBypager(pager);
        model.addAttribute("moviehalls",moviehalls);
        //总页数
        Integer total = moviehallDAO.findTotal();
        Integer pageCount=total/pager.getPageSize()+(total%pager.getPageSize()==0?0:1);
        pager.setPageCount(pageCount);

        model.addAttribute("pager",pager);

      return "manage/hallingDesign";
    }

    //判断放映厅是否存在
    @RequestMapping("isRenameHall")
    @ResponseBody
    public String isRenameHall(String moviehallname)
    {
        MoviehallDAO moviehallDAO=new MoviehallDAO();
        Moviehall moviehall=moviehallDAO.getBymovieHallName(moviehallname);
        if(moviehall!=null)
        {
            return "1";
        }
        else
        {
            return "0";
        }
    }

    //根据放映厅name来查询
    @RequestMapping("findByMovieHallname")
    public String findByHallname(String movieHallName,Model model)
    {
        MoviehallDAO moviehallDAO=new MoviehallDAO();
        Moviehall moviehall=moviehallDAO.getBymovieHallName(movieHallName);
        if(moviehall!=null)
        {
            model.addAttribute("moviehalls", Arrays.asList(moviehall)); // 将单个放映厅放入 List
        }
        else
        {
            // 用户不存在，可以返回一个空的列表或相应的提示
            model.addAttribute("moviehalls", Arrays.asList()); // 返回空列表
        }
        // 重新设置分页信息
        Pager pager = new Pager();
        pager.setPageNum(1); // 设置为第一页
        pager.setPageSize(5); // 每页显示5个用户

        Integer pageCount = 1;//查出或不查出只有一页
        pager.setPageCount(pageCount);
        model.addAttribute("pager", pager);

        return "manage/hallingDesign";//返回放映厅管理界面
    }


    //添加放映厅
    @RequestMapping("addHall")
    public String addHall(Moviehall moviehall)
    {
        MoviehallDAO moviehallDAO=new MoviehallDAO();
        moviehallDAO.add(moviehall);
        return "redirect:/manage/hallingDesign";
    }

    //判断影厅是否存在
    @RequestMapping("isExit")
    @ResponseBody
    public String isExit(String movieHallname)
    {
        MoviehallDAO moviehallDAO = new MoviehallDAO();
        Moviehall moviehall=moviehallDAO.getBymovieHallName(movieHallname);
        if(moviehall!=null)
        {
            return "1";
        }
        else
        {
            return "0";
        }
    }

    //修改放映厅
    @RequestMapping("updaeMoviehall")
    public String updaeMoviehall(Moviehall moviehall,HttpServletRequest request)
    {
        MoviehallDAO moviehallDAO = new MoviehallDAO();
        moviehallDAO.updateBymovieHallId(moviehall);
        return "redirect:/manage/hallingDesign";
    }

    //删除单个放映厅
    @RequestMapping("deleteByMoviehallid")
    public String deleteByMoviehallid(HttpServletRequest request)
    {
        Integer movieHallId=Integer.parseInt(request.getParameter("movieHallId"));
        //request.getParameter表单提交需要
        MoviehallDAO moviehallDAO=new MoviehallDAO();

        // 创建 Moviehall 对象并设置状态为 false
        Moviehall moviehall=new Moviehall();
        moviehall.setMovieHallId(movieHallId);
        //获取当前时间
        LocalDate now=LocalDate.now();
        //放映厅表设计没有时间

        moviehall.setStatus(false);
        // 设置 状态 为 false，表示放映厅已删除
        moviehallDAO.deleteByid(moviehall);
        return "redirect:/manage/hallingDesign";
    }


    //删除复选框选中的moviehall
    @RequestMapping("deleteMoreHall")
    public String deleteMoreHall(Integer[] movieids)
    {
        MoviehallDAO moviehallDAO=new MoviehallDAO();
        for(Integer moviehallid:movieids)
        {
            Moviehall moviehall=new Moviehall();
            moviehall.setMovieHallId(moviehallid);
            moviehall.setStatus(false);
            moviehallDAO.deleteByid(moviehall);
        }
        return "redirect:/manage/hallingDesign";
    }


    //这些@RequestMapping后面接的函数都不能重名，不管在不在同意controller中
    @RequestMapping("changeHall")
    public String change(Integer pageNum,Model model)
    {
        Pager pager =new Pager();
        pager.setPageNum(pageNum);
        pager.setPageSize(5);
        MoviehallDAO moviehallDAO=new MoviehallDAO();
        List<Moviehall> moviehalls =moviehallDAO.findBypager(pager);
        model.addAttribute("moviehalls",moviehalls);


        return "manage/moviehallList";//转发
    }







}
