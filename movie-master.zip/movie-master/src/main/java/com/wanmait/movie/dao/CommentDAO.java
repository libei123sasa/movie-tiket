package com.wanmait.movie.dao;

import com.wanmait.movie.util.JDBCDruidUtils;
import com.wanmait.movie.vo.*;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;
import org.springframework.util.SocketUtils;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CommentDAO
{


    //查询某页数据
    public List<Commentt> findByPager(Pager pager)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        List<Commentt> commentts=new ArrayList<>();
        String sql="select movie.movieName,userinfo.username,content,commentTime,commentId " +
                "from movie,userinfo,comment where movie.movieId=comment.movieId " +
                "and userinfo.userid=comment.userid and comment.status=1 order by commentTime desc,commentId desc limit ?,?";
        try {
            List<Map<String,Object>> mapList=queryRunner.query(sql,new MapListHandler(),(pager.getPageNum()-1)* pager.getPageSize(),pager.getPageSize());
            for(Map<String,Object> map:mapList)
            {
                Commentt commentt=new Commentt();
                commentt.setCommentId((Integer)map.get("commentId"));
                commentt.setMovieId((Integer) map.get("movieId"));
                commentt.setContent((String) map.get("content"));
                commentt.setCommentTime((Date) map.get("commentTime"));

                Movie movie=new Movie();
                movie.setMovieName((String) map.get("movieName"));

                Userinfo userinfo=new Userinfo();
                userinfo.setUsername((String) map.get("username"));

                commentt.setMovie(movie);
                commentt.setUserinfo(userinfo);
                commentts.add(commentt);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return commentts;
    }
    //总数
    public Integer findTotal()
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select count(*) from comment where status=1";
        try {
            Object object=queryRunner.query(sql,new ScalarHandler());
            return Integer.parseInt(object.toString());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }
    //删除评论
    public void deleteByCommentId(Commentt commentt)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="update comment set status=? where commentId=?";
        try {
            queryRunner.update(sql,commentt.isStatus(),commentt.getCommentId());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    //根据用户名查询评论的总记录数
    public Integer CountByUsername(String username)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select count(*) from comment,userinfo where comment.userid=userinfo.userid and comment.status=1 and userinfo.username=?";
        try {
            Object object=queryRunner.query(sql,new ScalarHandler(),username);
            return Integer.parseInt(object.toString());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }
    //根据用户名查询
    public List<Commentt> findByUsername(String username,Pager pager)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        List<Commentt> commentts=new ArrayList<>();
        String sql="select movie.movieName,userinfo.username,content,commentTime,commentId "+
                "from movie,userinfo,comment where movie.movieId=comment.movieId "+
               "and userinfo.userid=comment.userid and comment.status=1 " +
                "and userinfo.username=? limit ?,? order by commentTime desc";
        try {
            List<Map<String,Object>> mapList=queryRunner.query(sql,new MapListHandler(),username,(pager.getPageNum()-1)* pager.getPageSize(),pager.getPageSize());
            for(Map<String,Object> map:mapList)
            {
                Commentt commentt=new Commentt();
                commentt.setCommentId((Integer)map.get("commentId"));
                commentt.setMovieId((Integer) map.get("movieId"));
                commentt.setContent((String) map.get("content"));
                commentt.setCommentTime((Date) map.get("commentTime"));

                Movie movie=new Movie();
                movie.setMovieName((String) map.get("movieName"));

                Userinfo userinfo=new Userinfo();
                userinfo.setUsername((String) map.get("username"));

                commentt.setMovie(movie);
                commentt.setUserinfo(userinfo);
                commentts.add(commentt);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return commentts;
    }
    //查询所有敏感词汇
    public List<Senstive> findBySenstive()
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select words from senstive";
        try {
            List<Senstive> senstives=queryRunner.query(sql,new BeanListHandler<>(Senstive.class));
            return senstives;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }
    //查询谁评论的
    public List<Userinfo> findwho(Integer movieId,Pager pager)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        List<Userinfo> userinfos=new ArrayList<>();
        String sql="SELECT username,userPhoto,content,commentTime FROM userinfo,comment WHERE comment.userid=userinfo.userid AND comment.status=1 and movieId=? order by commentTime desc limit ?,?";
        try {
            List<Map<String,Object>> mapList = queryRunner.query(sql,new MapListHandler(),movieId,(pager.getPageNum()-1)* pager.getPageSize(),pager.getPageSize());
            for(Map<String,Object> map:mapList)
            {
                Userinfo userinfo=new Userinfo();
                userinfo.setUsername((String) map.get("username"));
                userinfo.setUserPhoto((String) map.get("userPhoto"));

                Commentt commentt=new Commentt();
                commentt.setContent((String) map.get("content"));
                commentt.setCommentTime((Date) map.get("commentTime"));
                userinfo.setCommentt(commentt);

                userinfos.add(userinfo);

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return userinfos;
    }
    //查询某一电影所有评论总数
    public Integer findmovieIdTotal(Integer movieId)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select count(*) from comment where status=1 and movieId=? ";
        try {
            Object object=queryRunner.query(sql,new ScalarHandler(),movieId);
            return Integer.parseInt(object.toString());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }
    //前台添加评论
    public void addpinglun(Commentt commentt)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="insert into comment(movieId,userid,content,commentTime) values(?,?,?,?)";
        try {
            queryRunner.update(sql,commentt.getMovieId(),commentt.getUserid(),commentt.getContent(),commentt.getCommentTime());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
