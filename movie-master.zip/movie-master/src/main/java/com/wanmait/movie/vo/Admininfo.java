package com.wanmait.movie.vo;

import lombok.Data;

@Data
public class Admininfo {
    private int id;//管理员id
    private String adname;//管理员用户名
    private String adpwd;//管理员密码
}
