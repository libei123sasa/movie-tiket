package com.wanmait.movie.dao;

public class QuestionDAO {
}
