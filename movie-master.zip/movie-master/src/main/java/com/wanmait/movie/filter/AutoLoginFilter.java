package com.wanmait.movie.filter;

import com.wanmait.movie.dao.AdminDAO;
import com.wanmait.movie.dao.UserinfoDAO;
import com.wanmait.movie.vo.Admininfo;
import com.wanmait.movie.vo.Userinfo;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter("/manage/*")
public class AutoLoginFilter implements Filter
{

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException
    {
        HttpServletRequest httpServletRequest=(HttpServletRequest) servletRequest;
        //获得本次访问路径
        String uri=httpServletRequest.getRequestURI();
        if (uri.contains("/login")||uri.contains("/checkadmin")||uri.contains(".js")||uri.contains(".exit"))
        {
            filterChain.doFilter(servletRequest,servletResponse);
            return;
        }
        //获得session对象
        HttpSession session=httpServletRequest.getSession();

        Object o=session.getAttribute("adminLogin");
        if(o!=null)//已登录
        {
            filterChain.doFilter(servletRequest,servletResponse);//放行
            return;
        }
        //去Cookie
        Cookie[] cookies=httpServletRequest.getCookies();
        //取所有cookie
        Admininfo admininfo=new Admininfo();
        if(cookies!=null)
        {
            for (Cookie cookie:cookies)
            {
                if(cookie.getName().equals("adname"))
                {
                    admininfo.setAdname(cookie.getValue());
                }
                if(cookie.getName().equals("adpwd"))
                {
                    admininfo.setAdpwd(cookie.getValue());
                }
            }
        }

        //session中间保存adminLogin
        AdminDAO adminDAO=new AdminDAO();
        Admininfo adminLogin=adminDAO.findByadname(admininfo.getAdname());
        session.setAttribute("adminLogin",adminLogin);

        filterChain.doFilter(servletRequest,servletResponse);//放行

    }
}
