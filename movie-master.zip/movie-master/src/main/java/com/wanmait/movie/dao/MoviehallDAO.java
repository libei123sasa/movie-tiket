package com.wanmait.movie.dao;

import com.wanmait.movie.util.JDBCDruidUtils;
import com.wanmait.movie.vo.Moviehall;
import com.wanmait.movie.vo.Pager;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;


import java.beans.IntrospectionException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.SplittableRandom;

public class MoviehallDAO
{
    //根据影厅name来查找影厅
    public Moviehall getBymovieHallName(String movieHallName)
    {
        QueryRunner queryRunner=new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql= "select * from moviehall where moviehallname = ?";
        try {
            Moviehall moviehall = queryRunner.query(sql,new BeanHandler<>(Moviehall.class),movieHallName);
            return moviehall;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }
    //根据影厅id来查找影厅
    public Moviehall getBymovieHallId(Integer movieHallId)
    {
        QueryRunner queryRunner=new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql= "select * from moviehall where moviehallid = ?";
        try {
            Moviehall moviehall = queryRunner.query(sql,new BeanHandler<>(Moviehall.class),movieHallId);
            return moviehall;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }
    //添加
    public void add(Moviehall moviehall)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "insert into moviehall(movieHallName,`rows`,`cols`) values(?,?,?)";
        try {
            queryRunner.update(sql,moviehall.getMovieHallName(),moviehall.getRows(),moviehall.getCols());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    //根据影厅name查询行数列数
    public Moviehall getRCbyMovie(String moviehallname)
    {
        QueryRunner queryRunner=new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select * from moviehall where moviehallname=?";
        try {
            Moviehall moviehall=queryRunner.query(sql,new BeanHandler<>(Moviehall.class),moviehallname);
            return moviehall;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }


 //查找所有影厅
    public List<Moviehall> getAllHall()
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select * from moviehall";
        try {
            List<Moviehall> moviehalls=queryRunner.query(sql,new BeanListHandler<>(Moviehall.class));
            return moviehalls;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }

    //根据放映厅id更改放映厅信息
    public void updateBymovieHallId(Moviehall moviehall)
    {
        QueryRunner queryRunner=new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="update moviehall set moviehallname=?,`rows`=?,`cols`=? where moviehallid = ?";
        //  String sql = "insert into moviehall(movieHallName,`rows`,`cols`) values(?,?,?)";
        try {
            queryRunner.update(sql,moviehall.getMovieHallName(),moviehall.getRows(),moviehall.getCols(),moviehall.getMovieHallId());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    //查寻放映厅数据总数
    public Integer findTotal()
    {
        QueryRunner queryRunner=new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select count(*) from moviehall where status=1";
        try {
            Object object =queryRunner.query(sql,new ScalarHandler<>());
            return Integer.parseInt(object.toString());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }


    //查询某一页的数据
    public List<Moviehall> findBypager(Pager pager)
    {
        List<Moviehall> moviehalls=new ArrayList<>();
        QueryRunner queryRunner=new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select * from moviehall where status=1 limit ?,? ";
        try {
            List<Map<String,Object>> mapList = queryRunner.query(sql,new MapListHandler(),(pager.getPageNum()-1)*pager.getPageSize(),pager.getPageSize());
            for(Map<String,Object> map:mapList)
            {
                Moviehall moviehall=new Moviehall();
               moviehall.setMovieHallId((Integer)map.get("movieHallId"));
                moviehall.setMovieHallName((String) map.get("moviehallname"));
                moviehall.setRows((Integer)  map.get("rows"));
                moviehall.setCols((Integer) map.get("cols"));

                moviehalls.add(moviehall);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return moviehalls;
    }
    //删除单个放映厅
    public void deleteByid(Moviehall moviehall)
    {
        QueryRunner queryRunner=new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "update moviehall set status=? where moviehallid=?";
        try {
            queryRunner.update(sql,moviehall.isStatus(),moviehall.getMovieHallId());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

}

