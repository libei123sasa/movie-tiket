package com.wanmait.movie.manageController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("manage")
public class ManageIndexController
{
    @RequestMapping("index")
    public String index() {
        return "manage/index";
    }


}

