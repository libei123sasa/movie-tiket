package com.wanmait.movie.webController;

import com.wanmait.movie.dao.UserinfoDAO;
import com.wanmait.movie.vo.Userinfo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("web")
public class WebForgetPwd2Controller {
    @RequestMapping("forgetPwd2")
    public String forgetPwd2(String username,HttpServletRequest request)
    {
        request.setAttribute("username",username);
        return "web/forgetPwd2";
    }

    @ResponseBody
    @RequestMapping("checkAnswer")
    public String checkAnswer(String x, String y, String z)
    {
        UserinfoDAO userinfoDAO = new UserinfoDAO();
        Userinfo qAbyUsername = userinfoDAO.getQAbyUsername(x, y, z);
        if(qAbyUsername!=null)//有数据
        {
            return "1";
        }
        else//没数据
        {
            return "0";
        }

    }
}
