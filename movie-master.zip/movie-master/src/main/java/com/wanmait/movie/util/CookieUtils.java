package com.wanmait.movie.util;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class CookieUtils
{
    public static void createCookie(String name, String value, int time, String path, HttpServletResponse response)
    {
        Cookie cookie=new Cookie(name,value);
        cookie.setMaxAge(time);
        cookie.setPath(path);
        response.addCookie(cookie);
    }
}
