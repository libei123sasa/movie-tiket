package com.wanmait.movie.filter;

import com.wanmait.movie.dao.UserinfoDAO;
import com.wanmait.movie.vo.Userinfo;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter("/web/*")
public  class WebAutoLoginFilter implements Filter {
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
        //获得本次访问路径
        String uri = httpServletRequest.getRequestURI();
        if (uri.contains("/login")||uri.contains(".js")||uri.contains("exit")||uri.contains("/check")||uri.contains("create")||uri.contains("/registe")||uri.contains("/forgetIndex")||uri.contains("/forgetPwd2")||uri.contains("/forgetPwd3")||uri.contains("/forgetPwd4")||uri.contains("/single")||uri.contains("/findBySortsAndPager"))
        {
            filterChain.doFilter(servletRequest,servletResponse);
            return;
        }
        //获得session对象
        HttpSession session = httpServletRequest.getSession();
        Object o = session.getAttribute("userinfo");
        if(o!=null)//已经登陆
        {
            filterChain.doFilter(servletRequest,servletResponse);//放行
            return;
        }
        //取cookie
        Cookie[] cookies = httpServletRequest.getCookies();
        //取所有的cookie
        Userinfo userinfo = new Userinfo();
        if(cookies!=null)
        {
            for(Cookie cookie:cookies)
            {
                if(cookie.getName().equals("username"))
                {
                    userinfo.setUsername(cookie.getValue());
                }
                if(cookie.getName().equals("password"))
                {
                    userinfo.setPassword(cookie.getValue());
                }
            }
        }

        //session中保存userinfo对象
        UserinfoDAO userinfoDAO = new UserinfoDAO();
        Userinfo userinfo1 = userinfoDAO.getByUsernameAndPassword(userinfo.getUsername(), userinfo.getPassword());
        session.setAttribute("userinfo",userinfo1);
        filterChain.doFilter(servletRequest,servletResponse);
    }
}
