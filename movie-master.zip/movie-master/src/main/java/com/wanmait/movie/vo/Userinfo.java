package com.wanmait.movie.vo;

import lombok.Data;

import java.sql.Date;
import java.sql.Timestamp;

@Data
public class Userinfo {
    private int userid;//用户id
    private String username;//用户名
    private String password;//密码
    private String userPhoto;//头像
    private String usermibao;//密保问题
    private String mbdaan;//密保答案
    private Date regTime;//注册时间
    private boolean status;//帐号状态
    private Timestamp updateTime;

    private Commentt commentt;
}
