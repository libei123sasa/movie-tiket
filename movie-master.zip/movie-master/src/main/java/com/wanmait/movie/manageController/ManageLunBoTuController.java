package com.wanmait.movie.manageController;

import com.wanmait.movie.dao.LunbotuDAO;
import com.wanmait.movie.dao.MovieDAO;
import com.wanmait.movie.dao.SortMovieDAO;
import com.wanmait.movie.vo.LunBoTu;
import com.wanmait.movie.vo.Movie;
import com.wanmait.movie.vo.Pager;
import com.wanmait.movie.vo.SortMovie;
import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.nio.channels.NonWritableChannelException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping("manage")
public class ManageLunBoTuController {
    @RequestMapping("lunbotuDesign")
    public String lunbotu(Model model)
    {
        Pager pager = new Pager();
        pager.setPageNum(1);
        pager.setPageSize(4);


        LunbotuDAO lunbotuDAO = new LunbotuDAO();
        List<LunBoTu> image = lunbotuDAO.findByPager(pager);
        model.addAttribute("images",image);

        //总页数
        Integer total = lunbotuDAO.getTotal();
        Integer pageCount = total/pager.getPageSize()+(total % pager.getPageSize()==0?0:1);
        pager.setPageCount(pageCount);
        model.addAttribute("pager",pager);
        return"manage/lunbotuDesign";


    }

    @RequestMapping("addImage")
    public String addImages(MultipartFile moviep, HttpServletRequest request, LunBoTu lunBoTu)
    {

        if (!moviep.isEmpty())
        {
            //获得/static/uploadImages文件夹绝对路径
            String filepath = request.getServletContext().getRealPath("/static/uploadImages");
            //获得源文件名
            String originalFilename = moviep.getOriginalFilename();
            //获得扩展名
            String extension = FilenameUtils.getExtension(originalFilename);
            //新文件名
            String filename = UUID.randomUUID().toString() + "." + extension;
            //保存
            try {
                moviep.transferTo(new File(filepath+"/"+filename));
            } catch (IOException e) {
                e.printStackTrace();
            }
            lunBoTu.setSrc("/movie/static/uploadImages/"+filename);
        }
        LunbotuDAO lunbotuDAO = new LunbotuDAO();
        lunbotuDAO.addImage(lunBoTu);
        return "redirect:/manage/lunbotuDesign";
    }

    @RequestMapping("lunbotuChange")
    public String movieChange(Integer pageNum, Model model)
    {

        Pager pager = new Pager();
        pager.setPageNum(pageNum);
        pager.setPageSize(4);
        LunbotuDAO lunbotuDAO = new LunbotuDAO();
        List<LunBoTu> image = lunbotuDAO.findByPager(pager);
        model.addAttribute("images",image);
        return "manage/lunbotuList";

    }

    //删除单个电影所属分类
    @RequestMapping("deleteById")
    public String deleteById(HttpServletRequest request)
    {
        LunbotuDAO lunbotuDAO = new LunbotuDAO();
        int id = Integer.parseInt(request.getParameter("id"));
        LunBoTu lunBoTu = new LunBoTu();
        lunBoTu.setId(id);
        lunbotuDAO.delImage(lunBoTu);
        return "redirect:/manage/lunbotuDesign";
    }

    //批量删除
    @RequestMapping("deleteMoreImage")
    public String deleteMore(Integer[] ids)
    {
        SortMovieDAO sortMovieDAO = new SortMovieDAO();
        for(Integer id:ids)
        {
            LunbotuDAO lunbotuDAO = new LunbotuDAO();
            LunBoTu lunBoTu = new LunBoTu();
            lunBoTu.setId(id);
            lunbotuDAO.delImage(lunBoTu);
        }
        return "redirect:/manage/lunbotuDesign";
    }

}
