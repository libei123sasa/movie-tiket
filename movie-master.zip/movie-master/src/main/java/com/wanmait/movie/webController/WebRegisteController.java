package com.wanmait.movie.webController;

import com.wanmait.movie.dao.UserinfoDAO;
import com.wanmait.movie.vo.Userinfo;
import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Controller
@RequestMapping("web")
public class WebRegisteController {

    @RequestMapping("isRename")
    @ResponseBody//不转发
    public String isRename(String x)
    {
        UserinfoDAO userinfoDAO = new UserinfoDAO();
        Userinfo userinfo = userinfoDAO.getByUsername(x);
        if(userinfo!=null)//重复
        {
            return "1";
        }else {//不重复
            return "0";
        }
    }

    @RequestMapping("registe")
    public String registe(Userinfo userinfo,  MultipartFile face, HttpServletRequest request)
    {
        String filename ="";
        if(!face.isEmpty())//选择文件
        {
            //获得/static/uploadImages文件夹的绝对路径
            String filepath = request.getServletContext().getRealPath("/static/uploadImages");

            //获得源文件名
            String originalFilename = face.getOriginalFilename();
            //获得扩展名
            String extension = FilenameUtils.getExtension(originalFilename);

            //新文件名
            filename = UUID.randomUUID().toString() + "." + extension;

            //保存
            try {
                face.transferTo(new File(filepath+"/"+filename));
            } catch (IOException e) {
                e.printStackTrace();
            }
            userinfo.setUserPhoto(filename);

        }
        UserinfoDAO userinfoDAO = new UserinfoDAO();
        // 获取当前时间
        LocalDate now = LocalDate.now();
        userinfo.setRegTime(Date.valueOf(now)); // 转换为 java.sql.Date
        LocalDateTime noww = LocalDateTime.now();
        Timestamp timestamp = Timestamp.valueOf(noww);
        // 转换为 java.sql.Timestamp
        userinfo.setUpdateTime(timestamp);
        userinfoDAO.add(userinfo);
        return "redirect:/web/login";
    }
}
