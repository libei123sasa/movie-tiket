package com.wanmait.movie.dao;

import com.wanmait.movie.util.JDBCDruidUtils;
import com.wanmait.movie.vo.*;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class PersonDao
{
    //查询用户所有订单
    public List<MovieOrder> findMovieOrder(Integer userid)
    {
        List<MovieOrder> movieOrders=new ArrayList<>();
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="SELECT m.movieName,mh.movieHallName,mo.orderNumber,mo.price,os.row,os.col,s.scheduleDate,s.scheduleTime FROM movieorder mo JOIN order_seat os ON mo.orderId = os.movieorderid JOIN schedule s ON os.scheduleid = s.scheduleId JOIN movie m ON s.movieId = m.movieId JOIN moviehall mh ON s.movieHallId = mh.moviehallId WHERE mo.userid = ? and mo.status=1";
        try {
            List<Map<String,Object>> mapList=queryRunner.query(sql,new MapListHandler(),userid);
            for(Map<String,Object> map:mapList)
            {
                MovieOrder movieOrder=new MovieOrder();
                Movie movie=new Movie();
                Moviehall moviehall=new Moviehall();
                Schedule schedule=new Schedule();
                Seat seat=new Seat();

                movieOrder.setOrderNumber((String) map.get("orderNumber"));
                movieOrder.setPrice((Float)map.get("price"));
                movie.setMovieName((String) map.get("movieName"));
                moviehall.setMovieHallName((String) map.get("movieHallName"));
                schedule.setScheduleDate((Date) map.get("scheduleDate"));
                schedule.setScheduleTime((Time) map.get("scheduleTime"));
                seat.setRow((Integer) map.get("row"));
                seat.setCol((Integer)map.get("col"));

                movieOrder.setMovie(movie);
                movieOrder.setMoviehall(moviehall);
                movieOrder.setSchedule(schedule);
                movieOrder.setSeat(seat);

                movieOrders.add(movieOrder);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return movieOrders;
    }

    //查userid和scheduleid
    public MovieOrder findBy(String orderNumber)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select userid,scheduleid from movieorder where orderNumber=? and status=1";
        try {
            MovieOrder movieOrder=queryRunner.query(sql,new BeanHandler<>(MovieOrder.class),orderNumber);
            return movieOrder;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }
    //取消订单
    public void deleteCancel(MovieOrder movieOrder1)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="UPDATE movieorder m,order_seat os SET m.`status`=0,os.`status`=0 WHERE m.scheduleid = os.scheduleid AND m.userid = os.userid AND os.scheduleid = ? AND m.userid =?";
        try {
            queryRunner.update(sql,movieOrder1.getScheduleId(),movieOrder1.getUserid());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    //获取订单下单时间
    public MovieOrder findPayTime(String cancelValue)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select payTime from movieorder where orderNumber=?";
        try {
            MovieOrder movieOrder=queryRunner.query(sql,new BeanHandler<>(MovieOrder.class),cancelValue);
            return  movieOrder;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }
}
