package com.wanmait.movie.webController;

import com.wanmait.movie.dao.CommentDAO;
import com.wanmait.movie.dao.MovieDAO;
import com.wanmait.movie.dao.MovieOrderDAO;
import com.wanmait.movie.vo.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("web")
public class WebSingleController {
    @RequestMapping("single")
    public String single(Model model,HttpServletRequest request,Integer movieId)
    {
        if (movieId != null) {
            movieId = Integer.parseInt(request.getParameter("movieId"));
        }
        Pager pager=new Pager();
        pager.setPageNum(1);
        pager.setPageSize(3);
        CommentDAO commentDAO=new CommentDAO();

        Integer total=commentDAO.findmovieIdTotal(movieId);
        Integer pageCount=total/pager.getPageSize()+(total%pager.getPageSize()==0?0:1);
        pager.setPageCount(pageCount);

        List<Userinfo> userinfos=commentDAO.findwho(movieId,pager);
        model.addAttribute("pager",pager);
        model.addAttribute("userinfos",userinfos);

        MovieDAO movieDAO=new MovieDAO();
        Movie movie=movieDAO.findBymovieID(movieId);

        model.addAttribute("movie",movie);

        return "web/single";
    }
    //Ajax
    @RequestMapping("WebChange")
    public String WebChange(Integer pageNum,Model model,Integer movieId)
    {
        Pager pager=new Pager();
        pager.setPageNum(pageNum);
        pager.setPageSize(3);

        CommentDAO commentDAO=new CommentDAO();
        List<Userinfo> userinfos=commentDAO.findwho(movieId,pager);
        model.addAttribute("userinfos",userinfos);

        return "web/singleList";
    }
    //添加评论
    @RequestMapping("pinglun")
    public String pinglun(HttpServletRequest request)
    {
        Integer movieId=Integer.parseInt(request.getParameter("plmovieId"));
        Integer userid=Integer.parseInt(request.getParameter("pluserid"));
        String content=request.getParameter("content");

        Commentt commentt=new Commentt();
        commentt.setUserid(userid);
        commentt.setMovieId(movieId);
        commentt.setContent(content);
        // 获取当前时间
        LocalDate now = LocalDate.now();
        commentt.setCommentTime(Date.valueOf(now)); // 转换为 java.sql.Date

        CommentDAO commentDAO=new CommentDAO();
        commentDAO.addpinglun(commentt);

        return "redirect:/web/single?movieId="+movieId;
    }

    //按照电影名查询电影id
    @RequestMapping("findMovieIdByName")
    public String findMovieIdByMovieName(String movieName)
    {
        MovieDAO movieDAO = new MovieDAO();
        Integer movieId = movieDAO.findMovieIdByMovieName(movieName);
        if (movieId!=null)
        {
            return "redirect:/web/single?movieId="+movieId;
        }
        if (movieId==null)
        {
            return"redirect:/web/error?movieName="+movieName;
        }
        return "web/index";
    }
    //ajax判断订单是否存在
    @RequestMapping("isHave")
    @ResponseBody
    public String isHave(Integer movieId, HttpServletRequest request, HttpSession session)
    {
        HttpSession session1= request.getSession();
        Object user=session1.getAttribute("userinfo");
        Userinfo userinfo=(Userinfo) user;

        MovieOrderDAO movieOrderDAO=new MovieOrderDAO();
        List<MovieOrder> movieOrders=movieOrderDAO.isOrderHave(movieId,userinfo.getUserid());
        //有订单
        if(movieOrders!=null)
        {
            return "1";
        }
        else
        {
            return "0";
        }
    }
}
