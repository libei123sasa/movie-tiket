package com.wanmait.movie.manageController;

import com.wanmait.movie.dao.MovieDAO;
import com.wanmait.movie.vo.Movie;
import com.wanmait.movie.vo.Pager;
import org.apache.commons.io.FilenameUtils;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@ControllerAdvice
@RequestMapping("manage")
public class ManageMovieDesignController
{

    //跳转到movieDesign页面，并查询所有电影数据
    //设置页码
    @RequestMapping("movieDesign")
    public String movie(Model model)
    {
        Pager pager = new Pager();
        pager.setPageNum(1);
        pager.setPageSize(6);

        MovieDAO movieDAO = new MovieDAO();
        List<Movie> movieList = movieDAO.findByPager(pager);
        model.addAttribute("movieList",movieList);

        //总页数
        Integer total = movieDAO.getTotal();
        Integer pageCount = total/pager.getPageSize()+(total % pager.getPageSize()==0?0:1);
        pager.setPageCount(pageCount);
        model.addAttribute("pager",pager);
        return "manage/movieDesign";
    }

//    获取所有电影
    @RequestMapping("getAllMovie")
    public String getAllMovie()
    {
        return null;
    }

    //添加电影
    @PostMapping("addMovie")
    public String addMovie(MultipartFile moviep, HttpServletRequest request,Movie movie)
    {
        if (!moviep.isEmpty())
        {
            //获得/static/uploadImages文件夹绝对路径
            String filepath = request.getServletContext().getRealPath("/static/uploadImages");
            //获得源文件名
            String originalFilename = moviep.getOriginalFilename();
            //获得扩展名
            String extension = FilenameUtils.getExtension(originalFilename);
            //新文件名
            String filename = UUID.randomUUID().toString() + "." + extension;
            //保存
            try {
                moviep.transferTo(new File(filepath+"/"+filename));
            } catch (IOException e) {
                e.printStackTrace();
            }
            movie.setMoviePhoto(filename);
            //获取当前时间
            LocalDateTime now = LocalDateTime.now();
            Timestamp timestamp = Timestamp.valueOf(now);
            // 转换为 java.sql.Timestamp
            movie.setUpdateTime(timestamp);
        }
        MovieDAO movieDAO = new MovieDAO();
        movieDAO.addMovie(movie);
        return "redirect:/manage/movieDesign";
    }

    //判断电影是否存在
    @RequestMapping("isMovieExist")
    @ResponseBody
    public String isMovieExist(String movieName)
    {
        MovieDAO movieDAO = new MovieDAO();
        Movie movie = movieDAO.findByMovieName2(movieName);
        if(movie!=null)
        {
            //电影已存在
            return "1";
        }
        else {
            return "0";
        }
    }

    //根据电影名查询
    @RequestMapping("findByMovieName")
    public String findByMovieName(String movieName,Model model)
    {
        MovieDAO movieDAO = new MovieDAO();



        Pager pager = new Pager();
        pager.setPageNum(1);
        pager.setPageSize(2);

        Integer total = movieDAO.findTotalByName(movieName);
        Integer pageCount = total/pager.getPageSize()+(total % pager.getPageSize()==0?0:1);
        pager.setPageCount(pageCount);
        List<Movie> movieList = movieDAO.findByMovieName(movieName,pager);
        model.addAttribute("movieList",movieList);
        model.addAttribute("pager",pager);
        return "manage/movieDesign";
    }

    //修改电影
    @RequestMapping("updateMovie")
    public String updateMovie(Movie movie,MultipartFile editMoviePhoto,HttpServletRequest request)
    {
        if (!editMoviePhoto.isEmpty())
        {
            //获得/static/uploadImages文件夹绝对路径
            String filepath = request.getServletContext().getRealPath("/static/uploadImages");
            //获得源文件名
            String originalFilename = editMoviePhoto.getOriginalFilename();
            //获得扩展名
            String extension = FilenameUtils.getExtension(originalFilename);
            //新文件名
            String filename = UUID.randomUUID().toString() + "." + extension;
            //保存
            try {
                editMoviePhoto.transferTo(new File(filepath+"/"+filename));
            } catch (IOException e) {
                e.printStackTrace();
            }
            movie.setMoviePhoto(filename);
        }
        MovieDAO movieDAO = new MovieDAO();
        movieDAO.updateByMovieId(movie);
        return "redirect:/manage/movieDesign";
    }

    //删除单个电影
    @RequestMapping("deleteByMovieId")
    public String deleteByMovieId(HttpServletRequest request)
    {
        int movieId = Integer.parseInt(request.getParameter("movieId"));
        MovieDAO movieDAO = new MovieDAO();
        //创建电影对象，修改电影状态status为false
        Movie movie = new Movie();
        movie.setMovieId(movieId);
        //获取当前时间
        LocalDateTime now = LocalDateTime.now();
        Timestamp timestamp = Timestamp.valueOf(now);
        // 转换为 java.sql.Timestamp
        movie.setUpdateTime(timestamp);// 转换为 java.sql.Date
        movie.setStatus(false);

        movieDAO.deleteByMovieId(movie);
        return "redirect:/manage/movieDesign";
    }

    //批量删除
    @RequestMapping("deleteMoreMovie")
    public String deleteMore(Integer[] movieIds)
    {
        MovieDAO movieDAO = new MovieDAO();
        for(Integer movieId:movieIds)
        {
            Movie movie = new Movie();
            movie.setMovieId(movieId);
            //获取当前时间
            LocalDateTime now = LocalDateTime.now();
            Timestamp timestamp = Timestamp.valueOf(now);
            // 转换为 java.sql.Timestamp
            movie.setUpdateTime(timestamp);
            movie.setStatus(false);

            movieDAO.deleteByMovieId(movie);
        }
        return "redirect:/manage/movieDesign";
    }

    //Ajax
    @RequestMapping("movieChange")
    public String movieChange(Integer pageNum, Model model, String val, HttpSession session)
    {
        if(val!="")
        {
            session.setAttribute("val",val);
        }
        Object o = session.getAttribute("val");
        if(o!=null)
        {
            String movieName = (String) o;
            Pager pager = new Pager();
            pager.setPageNum(pageNum);
            pager.setPageSize(2);
            MovieDAO movieDAO = new MovieDAO();
            List<Movie> movieList = movieDAO.findByMovieName(movieName,pager);
            model.addAttribute("movieList",movieList);
            session.invalidate();
        }else {
            Pager pager = new Pager();
            pager.setPageNum(pageNum);
            pager.setPageSize(6);
            MovieDAO movieDAO = new MovieDAO();
            List<Movie> movieList = movieDAO.findByPager(pager);
            model.addAttribute("movieList",movieList);
        }


        return "manage/movieList";

    }
}


