package com.wanmait.movie.vo;

import lombok.Data;

@Data
public class LunBoTu {
    private int id;
    private String src;
}
