package com.wanmait.movie.manageController;

import com.wanmait.movie.dao.CommentDAO;
import com.wanmait.movie.dao.UserinfoDAO;
import com.wanmait.movie.vo.Commentt;
import com.wanmait.movie.vo.Pager;
import com.wanmait.movie.vo.Userinfo;
import org.apache.commons.io.FilenameUtils;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@ControllerAdvice
@RequestMapping("manage")
public class ManageUserDesignController
{
    @RequestMapping("userDesign")
    //跳转到userDesign页面并查询出所有用户数据
    //设置页码
    public String userDesign(Model model)
    {
        Pager pager=new Pager();
        pager.setPageNum(1);
        pager.setPageSize(6);

        UserinfoDAO userinfoDAO=new UserinfoDAO();
        List<Userinfo> userinfos=userinfoDAO.findByPager(pager);
        model.addAttribute("userinfos",userinfos);
        //总页数
        Integer total=userinfoDAO.findTotal();
        Integer pageCount=total/pager.getPageSize()+(total%pager.getPageSize()==0?0:1);
        pager.setPageCount(pageCount);

        model.addAttribute("pager",pager);

        return "manage/userDesign";
    }
    //根据用户名查询
    @RequestMapping("findByUsername")
    public String findByUsername(String username,Model model)
    {
        Pager pager = new Pager();
        pager.setPageNum(1); // 设置为第一页
        pager.setPageSize(6); // 每页显示6个用户

        UserinfoDAO userinfoDAO=new UserinfoDAO();

        Integer total = userinfoDAO.countByUsername(username);
        Integer pageCount=total/pager.getPageSize()+(total%pager.getPageSize()==0?0:1);
        pager.setPageCount(pageCount);

        model.addAttribute("pager", pager);

        Userinfo userinfo=userinfoDAO.getByUsername(username);
        if(userinfo!=null)
        {
            List<Userinfo> userinfos = new ArrayList<>();
            userinfos.add(userinfo); // 将单个用户添加到 ArrayList
            model.addAttribute("userinfos", userinfos);
        }
        else
        {
            // 用户不存在，可以返回一个空的列表或相应的提示
            model.addAttribute("userinfos", new ArrayList<>()); // 返回空列表
        }
        return "manage/userDesign"; // 返回用户管理页面
    }

    //封禁用户
    @RequestMapping("deleteByUserName")
    @ResponseBody
    public String deleteByUserName(String username, int commentId)
    {
        Commentt commentt=new Commentt();
        commentt.setCommentId(commentId);
        commentt.setStatus(false);
        CommentDAO commentDAO=new CommentDAO();
        commentDAO.deleteByCommentId(commentt);
        System.out.println(commentId+",");
        UserinfoDAO userinfoDAO = new UserinfoDAO();
        int i = userinfoDAO.deleteByUserNaame(username);
        if(i==1)
        {
            return "1";
        }else {
            return "0";
        }

    }

    //Ajax
    @RequestMapping("change")
    public String change(Integer pageNum,Model model)
    {
        Pager pager = new Pager();
        pager.setPageNum(pageNum);
        pager.setPageSize(6);
        UserinfoDAO userinfoDAO=new UserinfoDAO();
        List<Userinfo> userinfos = userinfoDAO.findByPager(pager);
        model.addAttribute("userinfos",userinfos);

        return "manage/userList";//转发
    }
}
