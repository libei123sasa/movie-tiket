package com.wanmait.movie.dao;

import com.wanmait.movie.util.JDBCDruidUtils;
import com.wanmait.movie.vo.Movie;
import com.wanmait.movie.vo.Pager;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import javax.servlet.http.HttpServletRequest;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MovieDAO {

    //添加电影
    public void addMovie(Movie movie){
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "INSERT INTO movie(moviename,moviephoto,director,mainperformer,duration,AREA,releasedate,price,updatetime,opera) " +
                "VALUES (?,?,?,?,?,?,?,?,?,? )";
        try {
            queryRunner.update(
                    sql,
                    movie.getMovieName(),
                    movie.getMoviePhoto(),
                    movie.getDirector(),
                    movie.getMainPerformer(),
                    movie.getDuration(),
                    movie.getArea(),
                    movie.getReleaseDate(),
                    movie.getPrice(),
                    movie.getUpdateTime(),
                    movie.getOpera()
            );
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //查询所有电影
    public List<Movie> getAllMovie()
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select * from movie";
        try {
            List<Movie> movieList = queryRunner.query(sql, new BeanListHandler<>(Movie.class));
            return movieList;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    //查询电影表总条数
    public Integer getTotal()
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select count(*) from movie where status = 1";

        try {
            Object object = queryRunner.query(sql, new ScalarHandler<>());
            return Integer.parseInt(object.toString());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    //查询某页数据
    public List<Movie> findByPager(Pager pager)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select * from movie where status = 1 order by releaseDate desc limit ?,?";
        try {
            List<Movie> movieList = queryRunner.query(sql, new BeanListHandler<>(Movie.class), (pager.getPageNum() - 1) * pager.getPageSize(),pager.getPageSize());
            return movieList;

        } catch (SQLException e) {
            e.printStackTrace();
        }return null;
    }

    //根据电影名称查询
    public List<Movie> findByMovieName(String movieName,Pager pager)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "SELECT * FROM movie WHERE moviename like ? and status = 1 limit ?, ?";
        try {
            List<Movie> movieList = queryRunner.query(sql, new BeanListHandler<>(Movie.class),"%" +movieName+ "%",(pager.getPageNum() - 1) * pager.getPageSize(),pager.getPageSize());
            return movieList;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    //根据电影名模糊查询总条数
    public Integer findTotalByName(String movieName)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select count(*) from movie where status = 1 and  moviename like ?";
        try {
            Object o = queryRunner.query(sql, new ScalarHandler<>(), "%" + movieName + "%");
            return Integer.parseInt(o.toString());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    //根据电影名称查询
    public Movie findByMovieName2(String movieName)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "SELECT * FROM movie WHERE moviename = ? and status = 1";
        try {
            Movie movie = queryRunner.query(sql, new BeanHandler<>(Movie.class),movieName);
            return movie;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    //根据电影id修改电影信息
    public void updateByMovieId(Movie movie)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "update movie set moviename = ?,moviephoto = ?,director=?,mainperformer=?,duration=?,area=?,releasedate =?,price=?,opera=? where movieid=?";
        try {
            queryRunner.update(sql,movie.getMovieName(),movie.getMoviePhoto(),movie.getDirector(),movie.getMainPerformer(),movie.getDuration(),movie.getArea(),movie.getReleaseDate(),movie.getPrice(),movie.getOpera(),movie.getMovieId());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //删除单个电影
    public void deleteByMovieId(Movie movie)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "update movie set status = ?,updatetime = ? where movieid = ?";
        try {
            queryRunner.update(sql,movie.isStatus(),movie.getUpdateTime(),movie.getMovieId());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    //根据电影id查找电影信息
    public Movie findBymovieID(Integer movieId)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select * from movie where movieId=? and status=1";
        try {
            Movie movie=queryRunner.query(sql,new BeanHandler<>(Movie.class),movieId);
            return movie;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }

    //根据电影分类分页查询电影信息
    public List<Movie> findMovieBySortsAndPager(String sorts,Pager pager)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "SELECT m.* FROM movie m,sort_movie sm,sort s WHERE m.movieId = sm.movieid AND sm.sortsid = s.id AND s.sorts = ? limit ?,?";
        try {
            List<Movie> movieList = queryRunner.query(sql, new BeanListHandler<>(Movie.class), sorts, (pager.getPageNum() - 1) * pager.getPageSize(), pager.getPageSize());
            return movieList;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    //查询单个分类下电影总数
    public Integer findTotalBySorts(String sorts)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "SELECT COUNT(*) FROM movie m,sort_movie sm,sort s WHERE m.movieId = sm.movieid AND sm.sortsid = s.id AND s.sorts = ?";
        try {
            Object o = queryRunner.query(sql, new ScalarHandler<>(), sorts);
            int total = Integer.parseInt(o.toString());
            return total;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    //根据电影名称查询电影id
    public Integer findMovieIdByMovieName(String movieName)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select movieid from movie where moviename = ?";
        try {
            Movie movie = queryRunner.query(sql, new BeanHandler<>(Movie.class), movieName);
            if (movie!=null) {
                int movieId = movie.getMovieId();
                return movieId;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    //查找预售电影信息
    public List<Movie> findyvshoumovie()
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql="select * from movie where releaseDate > curdate() and status=1";
        try {
            List <Movie> movies=queryRunner.query(sql,new BeanListHandler<>(Movie.class));
            return movies;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }
    //查询当前放映电影
    public List<Movie> getCurrentMovie()
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select * from movie where releaseDate <= curdate() and status=1";
        try {
            List<Movie> movies = queryRunner.query(sql, new BeanListHandler<>(Movie.class));
            return movies;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
