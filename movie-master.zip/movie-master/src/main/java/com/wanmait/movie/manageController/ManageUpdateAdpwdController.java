package com.wanmait.movie.manageController;

import com.wanmait.movie.dao.AdminDAO;
import com.wanmait.movie.vo.Admininfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("manage")
public class ManageUpdateAdpwdController
{
    @RequestMapping("updateAdpwd")
    public String updateAdpwd(HttpSession session, Model model)
    {
        Admininfo adminLogin=(Admininfo) session.getAttribute("adminLogin");
        //从当前的 HTTP 会话（HttpSession）中获取名为 adminLogin 的属性，并将其转换为 Admininfo 类型。
        if (adminLogin!=null) {
            model.addAttribute("adminId", adminLogin.getId()); // 假设 Admininfo 有一个 getId() 方法
            return "manage/updateAdpwd"; // 返回 updateAdpwd 页面
        } else {
            return "redirect:/manage/login"; // 如果未登录，重定向到登录页面
        }
    }
@RequestMapping("savePassword")
    public String savePassword(HttpServletRequest request)
    {
        int id= Integer.parseInt(request.getParameter("adminId"));
        String newPassword=request.getParameter("newPassword");
        Admininfo admininfo=new Admininfo();
        admininfo.setId(id);
        admininfo.setAdpwd(newPassword);
        AdminDAO adminDAO=new AdminDAO();
        adminDAO.update(admininfo);
        return "/manage/login";//更新成功后重定向到登录页
    }
}
