package com.wanmait.movie.webController;

import com.wanmait.movie.dao.ScheduleDAO;
import com.wanmait.movie.vo.Schedule;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.sql.Time;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("web")
public class WebOrderController
{
    @RequestMapping("order")
    public String order(HttpServletRequest request, Model model)
    {
        Integer movieId=Integer.parseInt(request.getParameter("movieId"));

        ScheduleDAO scheduleDAO=new ScheduleDAO();
        List<Schedule> schedules=scheduleDAO.findScheduleByMovieId(movieId);

        model.addAttribute("schedules",schedules);
        model.addAttribute("movieId",movieId);

        return "web/order";
    }

    //Ajax
    @RequestMapping("Change")
    public String Change(Integer dateNum,Integer movieId,HttpServletRequest request,Model model)
    {

        ScheduleDAO scheduleDAO=new ScheduleDAO();
        if(dateNum==1)
        {
            List<Schedule> schedules=scheduleDAO.findScheduleByMovieId(movieId);
            model.addAttribute("schedules",schedules);
        }
        if(dateNum==2)
        {
            List<Schedule> schedules=scheduleDAO.findToScheduleByMovieId(movieId);
            model.addAttribute("schedules",schedules);
        }

        return "web/orderList";
    }
    //判断是否超过购票时间
    @RequestMapping("isTime")
    @ResponseBody
    public boolean isTime(Integer scheduleId)
    {
        //获取当前系统时间
        Date currentTime =new Date();

        ScheduleDAO scheduleDAO=new ScheduleDAO();
        Schedule schedule=scheduleDAO.findScheduleTime(scheduleId);
        Date scheduleDate = schedule.getScheduleDate(); // 获取电影的排期日期
        Time scheduleTime = schedule.getScheduleTime(); // 获取电影的放映时间

        // 将 scheduleDate 和 scheduleTime 合并成一个完整的 Date 对象
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(scheduleDate); // 设置日期部分
        calendar.set(Calendar.HOUR_OF_DAY, scheduleTime.getHours()); // 设置小时
        calendar.set(Calendar.MINUTE, scheduleTime.getMinutes()); // 设置分钟
        calendar.set(Calendar.SECOND, scheduleTime.getSeconds()); // 设置秒

        Date fullScheduleDateTime = calendar.getTime(); // 获取合并后的完整日期时间

        // 比较当前时间与电影放映时间
        return fullScheduleDateTime.after(currentTime); // 如果放映时间在当前时间之后，返回 true

    }
}
