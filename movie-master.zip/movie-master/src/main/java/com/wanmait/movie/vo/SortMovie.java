package com.wanmait.movie.vo;

import lombok.Data;

import java.sql.Timestamp;

@Data
public class SortMovie {
    private int id;
    private int movieid;//电影id
    private int sortsid;//类型id
    private Timestamp updateTime;//修改时间
    private boolean status;//状态

    private Sort sort;
    private Movie movie;
}
