package com.wanmait.movie.vo;

import lombok.Data;

import java.sql.Date;
import java.sql.Time;

@Data
public class Schedule {
    private Integer scheduleId;//场次id
    private Integer movieId;//电影id
    private Integer movieHallId;//放映厅id
    private Date scheduleDate;//场次安排日期
    private Time scheduleTime;//场次安排时间
    //多表关联
    private Moviehall moviehall;
    private Movie movie;
    private boolean status;
}
