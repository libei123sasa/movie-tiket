package com.wanmait.movie.filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter("/web/*")
public class WebIsLoginFilter implements Filter {
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException
    {

        HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
        //获得访问路径
        String uri = httpServletRequest.getRequestURI();
        if(uri.contains("/login")||uri.contains("/index")||uri.contains("/create")||uri.contains("/isRename")||uri.contains("/check")||uri.contains("/registe")||uri.contains("/forgetIndex")||uri.contains("/forgetPwd2")||uri.contains("/forgetPwd3")||uri.contains("/forgetPwd4")||uri.contains("/single")||uri.contains("/findBySortsAndPager"))
        {
            filterChain.doFilter(servletRequest,servletResponse);
            return ;
        }

        //获得session
        HttpSession session = httpServletRequest.getSession();
        Object o = session.getAttribute("userinfo");
        if(o!=null)
        {
            filterChain.doFilter(servletRequest,servletResponse);

        }else
        {
            String path = httpServletRequest.getContextPath();
            //把servletresponse强制转化为httpServletResponse，因为前者不可转发
            HttpServletResponse httpServletResponse= (HttpServletResponse) servletResponse;
            httpServletResponse.sendRedirect(path+"/web/login");
        }


    }
}
