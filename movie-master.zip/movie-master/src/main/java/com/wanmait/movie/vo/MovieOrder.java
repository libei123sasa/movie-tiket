package com.wanmait.movie.vo;

import lombok.Data;

import java.sql.Timestamp;

@Data
public class MovieOrder {
    private int orderId;//订单id
    private int scheduleId;//场次id
    private int rows;//行号
    private int cols;//列号
    private float price;//票价
    private Integer userid;//用户名
    private String orderNumber;//订单编号
    private Timestamp payTime;
    private boolean staus;//订单状态

    private Userinfo userinfo;
    private Movie movie;
    private Schedule schedule;
    private Moviehall moviehall;
    private Seat seat;
}
