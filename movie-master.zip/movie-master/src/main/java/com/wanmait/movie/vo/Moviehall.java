package com.wanmait.movie.vo;

import lombok.Data;

@Data
public class Moviehall {
    private int movieHallId;//放映厅id
    private String movieHallName;//放映厅名称
    private int rows;//排数
    private int cols;//列数
    private boolean status;//放映厅状态
}
