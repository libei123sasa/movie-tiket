package com.wanmait.movie.dao;

import com.wanmait.movie.util.JDBCDruidUtils;
import com.wanmait.movie.vo.LunBoTu;
import com.wanmait.movie.vo.Movie;
import com.wanmait.movie.vo.Pager;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import java.sql.SQLException;
import java.util.List;

public class LunbotuDAO {
    //查询轮播图
    public List<LunBoTu> findImage()
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select * from lunbotu";
        try {
            List<LunBoTu> src = queryRunner.query(sql, new BeanListHandler<>(LunBoTu.class));
            return src;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    //查询轮播图总条数
    public Integer getTotal()
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select count(*) from lunbotu ";

        try {
            Object object = queryRunner.query(sql, new ScalarHandler<>());
            return Integer.parseInt(object.toString());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    //查询某页数据
    public List<LunBoTu> findByPager(Pager pager)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "select * from lunbotu  limit ?,?";
        try {
            List<LunBoTu> lunBoTuList = queryRunner.query(sql, new BeanListHandler<>(LunBoTu.class), (pager.getPageNum() - 1) * pager.getPageSize(),pager.getPageSize());
            return lunBoTuList;

        } catch (SQLException e) {
            e.printStackTrace();
        }return null;
    }

    //添加轮播图
    public void addImage(LunBoTu lunBoTu)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "insert into lunbotu(src) values(?)";
        try {
            queryRunner.update(sql,lunBoTu.getSrc());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //删除轮播图
    public void delImage(LunBoTu lunBoTu)
    {
        QueryRunner queryRunner = new QueryRunner(JDBCDruidUtils.getDataSource());
        String sql = "delete from lunbotu where id = ?";
        try {
            queryRunner.update(sql,lunBoTu.getId());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
