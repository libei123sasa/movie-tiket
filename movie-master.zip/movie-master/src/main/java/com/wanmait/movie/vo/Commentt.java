package com.wanmait.movie.vo;

import lombok.Data;

import java.sql.Date;

@Data
public class Commentt {
    private Integer commentId;//评论id
    private Integer movieId;//电影id
    private String content;//评论内容
    private Integer userid;//用户id
    private Date commentTime;//评论时间
    private boolean status;
    private  Movie movie;
    private Userinfo userinfo;
}
