package com.wanmait.movie.util;

import com.alibaba.druid.pool.DruidDataSource;

public class JDBCDruidUtils
{
private static DruidDataSource druidDataSource = new DruidDataSource();

    static {
        // 连接数据库
        druidDataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
        druidDataSource.setUrl("jdbc:mysql://database-1.cpeweeis2sdg.rds.cn-north-1.amazonaws.com.cn:3306/wm240717db1");
        druidDataSource.setUsername("wm240717user1");
        druidDataSource.setPassword("wanmait_U7c8Es3");
        // 链接要素
        druidDataSource.setInitialSize(3); // 初始连接数
        druidDataSource.setMinIdle(3); // 最少活动连接数
        druidDataSource.setMaxActive(10); // 最多连接数
        druidDataSource.setMaxWait(10000); // 最长等待时间
    }

    public static DruidDataSource getDataSource() {
        return druidDataSource;
    }
}
