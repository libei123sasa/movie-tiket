package com.wanmait.movie.vo;

import lombok.Data;

@Data
public class Sort {
    private int id;//类型id
    private String sorts;//类型名称
    private boolean status;
}
