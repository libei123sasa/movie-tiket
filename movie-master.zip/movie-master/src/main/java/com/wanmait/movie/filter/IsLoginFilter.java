package com.wanmait.movie.filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter("/manage/*")
public class IsLoginFilter implements Filter
{
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException
    {
        HttpServletRequest httpServletRequest=(HttpServletRequest) servletRequest;
        //获得访问路径
        String uri=httpServletRequest.getRequestURI();
        if(uri.contains("/manage/login")||uri.contains("/manage/checkadmin"))
        {
            filterChain.doFilter(servletRequest,servletResponse);
            return;
        }
        //获得session
        HttpSession session=httpServletRequest.getSession();
        Object o=session.getAttribute("adminLogin");
        if(o!=null)
        {
            filterChain.doFilter(servletRequest,servletResponse);//放行
        }
        else
        {
            String path=httpServletRequest.getContextPath();
            HttpServletResponse httpServletResponse=(HttpServletResponse) servletResponse;
            httpServletResponse.sendRedirect(path+"/manage/login");
        }
    }
}
